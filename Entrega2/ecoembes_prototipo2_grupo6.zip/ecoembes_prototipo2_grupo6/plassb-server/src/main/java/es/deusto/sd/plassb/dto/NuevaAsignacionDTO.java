package es.deusto.sd.plassb.dto;

import java.time.LocalDate;

import io.swagger.v3.oas.annotations.media.Schema;

public class NuevaAsignacionDTO {
	@Schema(description = "Date of the assignment (yyyy-MM-dd)", example = "2026-11-21")
	private LocalDate fecha;
	@Schema(description = "Total number of containers sent to the plant", example = "3")
	private int numContenedores;
	@Schema(description = "Total estimated number of packagings", example = "3500")
	private int totalEnvases;

	public NuevaAsignacionDTO() { }

	public NuevaAsignacionDTO(LocalDate fecha, int numContenedores, int totalEnvases) {
		this.fecha = fecha;
		this.numContenedores = numContenedores;
		this.totalEnvases = totalEnvases;
	}

	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	public int getNumContenedores() {
		return numContenedores;
	}

	public void setNumContenedores(int numContenedores) {
		this.numContenedores = numContenedores;
	}

	public int getTotalEnvases() {
		return totalEnvases;
	}

	public void setTotalEnvases(int totalEnvases) {
		this.totalEnvases = totalEnvases;
	}
}
