package es.deusto.sd.ecoembes.entity;

import java.time.LocalDateTime;
import java.util.List;

// Alerta de saturación enviada automáticamente por correo al personal de Ecoembes
public class AlertaSaturacion {
	private LocalDateTime fechaHora;
	private int contenedoresAltos;
	private int totalContenedores;
	private double porcentaje;
	private List<String> destinatarios;
	private String mensaje;

	public AlertaSaturacion() { }

	public AlertaSaturacion(LocalDateTime fechaHora, int contenedoresAltos, int totalContenedores, double porcentaje,
			List<String> destinatarios, String mensaje) {
		this.fechaHora = fechaHora;
		this.contenedoresAltos = contenedoresAltos;
		this.totalContenedores = totalContenedores;
		this.porcentaje = porcentaje;
		this.destinatarios = destinatarios;
		this.mensaje = mensaje;
	}

	// Getters and setters
	public LocalDateTime getFechaHora() {
		return fechaHora;
	}

	public void setFechaHora(LocalDateTime fechaHora) {
		this.fechaHora = fechaHora;
	}

	public int getContenedoresAltos() {
		return contenedoresAltos;
	}

	public void setContenedoresAltos(int contenedoresAltos) {
		this.contenedoresAltos = contenedoresAltos;
	}

	public int getTotalContenedores() {
		return totalContenedores;
	}

	public void setTotalContenedores(int totalContenedores) {
		this.totalContenedores = totalContenedores;
	}

	public double getPorcentaje() {
		return porcentaje;
	}

	public void setPorcentaje(double porcentaje) {
		this.porcentaje = porcentaje;
	}

	public List<String> getDestinatarios() {
		return destinatarios;
	}

	public void setDestinatarios(List<String> destinatarios) {
		this.destinatarios = destinatarios;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
}
