package es.deusto.sd.ecoembes.dao;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import es.deusto.sd.ecoembes.entity.Asignacion;

public interface AsignacionRepository extends JpaRepository<Asignacion, Long> {
	List<Asignacion> findAllByOrderByIdAsc();

	// Número de asignaciones de una fecha que incluyen un contenedor (un contenedor solo se asigna una vez por fecha)
	@Query("select count(a) from Asignacion a join a.contenedores c where a.fecha = :fecha and c.id = :contenedorId")
	long countByFechaAndContenedor(@Param("fecha") LocalDate fecha, @Param("contenedorId") long contenedorId);
}
