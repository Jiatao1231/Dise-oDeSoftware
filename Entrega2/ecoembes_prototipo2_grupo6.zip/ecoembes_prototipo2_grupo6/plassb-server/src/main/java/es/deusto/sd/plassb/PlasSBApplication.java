package es.deusto.sd.plassb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlasSBApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlasSBApplication.class, args);
	}
}
