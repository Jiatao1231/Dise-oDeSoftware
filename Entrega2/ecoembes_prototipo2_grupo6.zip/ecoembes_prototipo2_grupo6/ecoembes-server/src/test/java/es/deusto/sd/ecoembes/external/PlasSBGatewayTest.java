package es.deusto.sd.ecoembes.external;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.sun.net.httpserver.HttpServer;

// Prueba el gateway contra un servidor HTTP falso (el del JDK) que simula la API REST de PlasSB
class PlasSBGatewayTest {

	private HttpServer server;
	private final AtomicInteger status = new AtomicInteger(200);
	private final AtomicReference<String> cuerpoRespuesta = new AtomicReference<>("{}");
	private final AtomicReference<String> rutaRecibida = new AtomicReference<>();
	private final AtomicReference<String> cuerpoRecibido = new AtomicReference<>();
	private final LocalDate fecha = LocalDate.of(2026, 11, 21);

	@BeforeEach
	void setUp() throws IOException {
		server = HttpServer.create(new InetSocketAddress("localhost", 0), 0);
		server.createContext("/", exchange -> {
			rutaRecibida.set(exchange.getRequestMethod() + " " + exchange.getRequestURI());
			cuerpoRecibido.set(new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8));

			byte[] bytes = cuerpoRespuesta.get().getBytes(StandardCharsets.UTF_8);
			exchange.getResponseHeaders().add("Content-Type", "application/json");
			exchange.sendResponseHeaders(status.get(), bytes.length == 0 ? -1 : bytes.length);

			if (bytes.length > 0) {
				exchange.getResponseBody().write(bytes);
			}

			exchange.close();
		});
		server.start();
	}

	@AfterEach
	void tearDown() {
		server.stop(0);
	}

	private PlasSBGateway gateway() {
		return new PlasSBGateway("http://localhost:" + server.getAddress().getPort());
	}

	@Test
	void capacityIsRequestedAndParsed() {
		cuerpoRespuesta.set("{\"planta\":\"PlasSB Ltd.\",\"fecha\":\"2026-11-21\",\"capacidadDisponible\":0.55}");

		assertEquals(0.55, gateway().getCapacidadDisponible(fecha), 0.000001);
		assertEquals("GET /plassb/capacidad?fecha=2026-11-21", rutaRecibida.get());
	}

	@Test
	void assignmentIsSentAsJson() {
		status.set(201);

		gateway().asignarContenedores(fecha, 3, 3500);

		assertEquals("POST /plassb/asignaciones", rutaRecibida.get());
		assertEquals("{\"fecha\":\"2026-11-21\",\"numContenedores\":3,\"totalEnvases\":3500}", cuerpoRecibido.get());
	}

	@Test
	void errorStatusesAreTranslated() {
		status.set(409);
		RuntimeException e = assertThrows(RuntimeException.class, () -> gateway().asignarContenedores(fecha, 1, 10));
		assertEquals("Insufficient plant capacity", e.getMessage());

		status.set(400);
		assertThrows(IllegalArgumentException.class, () -> gateway().getCapacidadDisponible(fecha));

		status.set(500);
		e = assertThrows(RuntimeException.class, () -> gateway().getCapacidadDisponible(fecha));
		assertEquals("Plant service unavailable", e.getMessage());
	}

	@Test
	void unreachableServiceIsReportedAsUnavailable() {
		int puerto = server.getAddress().getPort();
		server.stop(0);

		RuntimeException e = assertThrows(RuntimeException.class,
				() -> new PlasSBGateway("http://localhost:" + puerto).getCapacidadDisponible(fecha));

		assertEquals("Plant service unavailable", e.getMessage());
	}
}
