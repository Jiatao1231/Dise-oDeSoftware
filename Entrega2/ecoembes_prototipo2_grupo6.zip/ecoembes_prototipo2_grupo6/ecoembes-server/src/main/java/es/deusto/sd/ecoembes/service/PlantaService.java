package es.deusto.sd.ecoembes.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import es.deusto.sd.ecoembes.dao.PlantaRepository;
import es.deusto.sd.ecoembes.dao.RegistroPlantaRepository;
import es.deusto.sd.ecoembes.entity.PlantaReciclaje;
import es.deusto.sd.ecoembes.entity.RegistroPlantaReciclaje;
import es.deusto.sd.ecoembes.external.IPlantaGateway;
import es.deusto.sd.ecoembes.external.PlantaGatewayFactory;

@Service
public class PlantaService {

	// La capacidad de las plantas solo está disponible con 10 días de antelación
	public static final int DIAS_ANTELACION = 10;

	private final PlantaRepository plantaRepository;
	private final RegistroPlantaRepository registroPlantaRepository;
	private final PlantaGatewayFactory gatewayFactory;

	public PlantaService(PlantaRepository plantaRepository, RegistroPlantaRepository registroPlantaRepository,
			PlantaGatewayFactory gatewayFactory) {
		this.plantaRepository = plantaRepository;
		this.registroPlantaRepository = registroPlantaRepository;
		this.gatewayFactory = gatewayFactory;
	}

	// Obtiene todas las plantas de reciclaje
	public List<PlantaReciclaje> getPlantas() {
		return plantaRepository.findAllByOrderByIdAsc();
	}

	// Obtiene una planta de reciclaje por su ID
	public PlantaReciclaje getPlantaById(long id) {
		return plantaRepository.findById(id).orElse(null);
	}

	// Obtiene la capacidad (en toneladas) disponible en una fecha concreta para una planta concreta.
	// El dato lo proporciona el servicio externo de la planta (a través de su Service Gateway; este
	// servicio no sabe si es REST o sockets) y se deja registrado en la BD.
	public double getCapacidadDisponible(long plantaId, LocalDate fecha) {
		validarFechaConsulta(fecha);

		PlantaReciclaje planta = getPlantaById(plantaId);

		if (planta == null) {
			throw new RuntimeException("Plant not found");
		}

		IPlantaGateway gateway = gatewayFactory.crearGateway(planta);
		double capacidad = gateway.getCapacidadDisponible(fecha);

		// Solo se mantiene un registro por planta y fecha: si ya había uno, se actualiza
		Optional<RegistroPlantaReciclaje> existente = registroPlantaRepository.findByPlantaIdAndFecha(plantaId, fecha);
		RegistroPlantaReciclaje registro = existente.orElseGet(() -> new RegistroPlantaReciclaje(fecha, capacidad, planta));
		registro.setCapacidadDisponible(capacidad);
		registroPlantaRepository.save(registro);

		return capacidad;
	}

	// Una fecha es válida cuando no está más de 10 días en el futuro
	public static void validarFechaConsulta(LocalDate fecha) {
		if (fecha == null || fecha.isAfter(LocalDate.now().plusDays(DIAS_ANTELACION))) {
			throw new IllegalArgumentException("Invalid date");
		}
	}
}
