package es.deusto.sd.plassb;

import java.time.LocalDate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import es.deusto.sd.plassb.dao.CapacidadDiariaRepository;
import es.deusto.sd.plassb.entity.CapacidadDiaria;

@Configuration
public class DataInitializer {

	private static final Logger logger = LoggerFactory.getLogger(DataInitializer.class);

	private final TransactionTemplate transactionTemplate;

	public DataInitializer(PlatformTransactionManager transactionManager) {
		this.transactionTemplate = new TransactionTemplate(transactionManager);
	}

	@Bean
	CommandLineRunner initData(CapacidadDiariaRepository capacidadRepository,
			@Value("${plassb.capacidad-diaria:0.60}") double capacidadDiaria) {
		// Declara la capacidad de los próximos días (10 de antelación + margen). Solo añade las fechas que
		// faltan, por lo que se puede ejecutar en cada arranque sin duplicar datos.
		return args -> transactionTemplate.executeWithoutResult(status -> {
			LocalDate hoy = LocalDate.now();
			int nuevas = 0;

			for (int dias = -3; dias <= 14; dias++) {
				LocalDate fecha = hoy.plusDays(dias);

				if (capacidadRepository.findByFecha(fecha).isEmpty()) {
					capacidadRepository.save(new CapacidadDiaria(fecha, capacidadDiaria));
					nuevas++;
				}
			}

			logger.info("Daily capacities saved: {} new days ({} t/day)", nuevas, capacidadDiaria);
		});
	}
}
