package es.deusto.sd.ecoembes.entity;

import java.time.LocalDate;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

// Actualiza el estado del contenedor y el número de envases depositados en él en una fecha concreta
@Entity
public class RegistroContenedor {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(nullable = false)
	private LocalDate fecha;

	private int numEnvases;

	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	private EstadoContenedor nivelLlenado;

	@ManyToOne
	@JoinColumn(name = "contenedor_id", nullable = false)
	private Contenedor contenedor;

	public RegistroContenedor() { }

	public RegistroContenedor(LocalDate fecha, int numEnvases, EstadoContenedor nivelLlenado, Contenedor contenedor) {
		this.fecha = fecha;
		this.numEnvases = numEnvases;
		this.nivelLlenado = nivelLlenado;
		this.contenedor = contenedor;
	}

	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	public int getNumEnvases() {
		return numEnvases;
	}

	public void setNumEnvases(int numEnvases) {
		this.numEnvases = numEnvases;
	}

	public EstadoContenedor getNivelLlenado() {
		return nivelLlenado;
	}

	public void setNivelLlenado(EstadoContenedor nivelLlenado) {
		this.nivelLlenado = nivelLlenado;
	}

	public Contenedor getContenedor() {
		return contenedor;
	}

	public void setContenedor(Contenedor contenedor) {
		this.contenedor = contenedor;
	}

	// hashCode and equals (un registro por contenedor y fecha)
	@Override
	public int hashCode() {
		return Objects.hash(contenedor, fecha);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RegistroContenedor other = (RegistroContenedor) obj;
		return Objects.equals(contenedor, other.contenedor) &&
			   Objects.equals(fecha, other.fecha);
	}
}
