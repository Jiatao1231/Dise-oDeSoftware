package es.deusto.sd.ecoembes.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import es.deusto.sd.ecoembes.dao.ContenedorRepository;
import es.deusto.sd.ecoembes.entity.Contenedor;
import es.deusto.sd.ecoembes.entity.EstadoContenedor;
import es.deusto.sd.ecoembes.entity.RegistroContenedor;

@Service
public class ContenedorService {

	private final ContenedorRepository contenedorRepository;

	public ContenedorService(ContenedorRepository contenedorRepository) {
		this.contenedorRepository = contenedorRepository;
	}

	// Obtiene todos los contenedores
	public List<Contenedor> getContenedores() {
		return contenedorRepository.findAllByOrderByIdAsc();
	}

	// Obtener un contenedor por su ID
	public Contenedor getContenedorById(long id) {
		return contenedorRepository.findById(id).orElse(null);
	}

	// Crea un nuevo contenedor
	@Transactional
	public Contenedor crearContenedor(long id, String ubicacion, String codigoPostal, int capacidadInicial) {
		if (ubicacion == null || ubicacion.isBlank() || codigoPostal == null || codigoPostal.isBlank()
				|| capacidadInicial <= 0) {
			throw new IllegalArgumentException("Invalid container data");
		}

		if (contenedorRepository.existsById(id)) {
			throw new RuntimeException("Container already exists");
		}

		return contenedorRepository.save(new Contenedor(id, ubicacion, codigoPostal, capacidadInicial));
	}

	// Registra la actualización diaria enviada por el sensor de un contenedor
	@Transactional
	public void actualizarContenedor(long id, LocalDate fecha, int numEnvases, EstadoContenedor nivelLlenado) {
		if (numEnvases < 0 || nivelLlenado == null) {
			throw new IllegalArgumentException("Invalid container data");
		}

		// Si no hay fecha, se registra la actualización para hoy
		LocalDate fechaRegistro = (fecha != null) ? fecha : LocalDate.now();

		if (fechaRegistro.isAfter(LocalDate.now())) {
			throw new IllegalArgumentException("Invalid container data");
		}

		Optional<Contenedor> contenedor = contenedorRepository.findById(id);

		if (contenedor.isEmpty()) {
			throw new RuntimeException("Container not found");
		}

		contenedor.get().addRegistro(fechaRegistro, numEnvases, nivelLlenado);
		contenedorRepository.save(contenedor.get());
	}

	// Obtiene las actualizaciones de un contenedor entre dos fechas (ambas incluidas)
	public List<RegistroContenedor> getRegistrosByFechas(long id, LocalDate fechaInicio, LocalDate fechaFin) {
		if (fechaInicio == null || fechaFin == null || fechaInicio.isAfter(fechaFin)) {
			throw new IllegalArgumentException("Invalid date range");
		}

		Optional<Contenedor> contenedor = contenedorRepository.findById(id);

		if (contenedor.isEmpty()) {
			throw new RuntimeException("Container not found");
		}

		return contenedor.get().getRegistros().stream()
				.filter(r -> !r.getFecha().isBefore(fechaInicio) && !r.getFecha().isAfter(fechaFin))
				.sorted((r1, r2) -> r1.getFecha().compareTo(r2.getFecha()))
				.toList();
	}

	// Obtiene el estado de los contenedores de una zona (código postal) en una fecha concreta
	public List<RegistroContenedor> getRegistrosByZona(String codigoPostal, LocalDate fecha) {
		if (codigoPostal == null || codigoPostal.isBlank() || fecha == null) {
			throw new IllegalArgumentException("Invalid date range");
		}

		return contenedorRepository.findByCodigoPostalOrderByIdAsc(codigoPostal).stream()
				.map(c -> c.getRegistro(fecha))
				.filter(r -> r.isPresent())
				.map(r -> r.get())
				.toList();
	}

	// Modifica los datos principales de un contenedor existente
	@Transactional
	public Contenedor modificarContenedor(long id, String ubicacion, String codigoPostal, int capacidadInicial) {
		if (ubicacion == null || ubicacion.isBlank() || codigoPostal == null || codigoPostal.isBlank()
				|| capacidadInicial <= 0) {
			throw new IllegalArgumentException("Invalid container data");
		}

		Optional<Contenedor> contenedor = contenedorRepository.findById(id);

		if (contenedor.isEmpty()) {
			throw new RuntimeException("Container not found");
		}

		contenedor.get().setUbicacion(ubicacion);
		contenedor.get().setCodigoPostal(codigoPostal);
		contenedor.get().setCapacidadInicial(capacidadInicial);

		return contenedorRepository.save(contenedor.get());
	}
}
