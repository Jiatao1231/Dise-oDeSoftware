package es.deusto.sd.ecoembes.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;

import es.deusto.sd.ecoembes.dao.AsignacionRepository;
import es.deusto.sd.ecoembes.dao.ContenedorRepository;
import es.deusto.sd.ecoembes.dao.PersonalRepository;
import es.deusto.sd.ecoembes.dao.PlantaRepository;
import es.deusto.sd.ecoembes.dao.RegistroPlantaRepository;
import es.deusto.sd.ecoembes.entity.Asignacion;
import es.deusto.sd.ecoembes.entity.EstadoContenedor;
import es.deusto.sd.ecoembes.entity.PersonalEcoembes;
import es.deusto.sd.ecoembes.entity.PlantaReciclaje;
import es.deusto.sd.ecoembes.entity.TipoServicioPlanta;
import es.deusto.sd.ecoembes.external.IPlantaGateway;
import es.deusto.sd.ecoembes.external.PlantaGatewayFactory;

@DataJpaTest
class AsignacionServiceTest {

	@Autowired private ContenedorRepository contenedorRepository;
	@Autowired private PlantaRepository plantaRepository;
	@Autowired private RegistroPlantaRepository registroPlantaRepository;
	@Autowired private AsignacionRepository asignacionRepository;
	@Autowired private PersonalRepository personalRepository;

	private ContenedorService contenedorService;
	private AsignacionService asignacionService;
	private IPlantaGateway gateway;
	private PersonalEcoembes personal;
	private final LocalDate hoy = LocalDate.now();

	@BeforeEach
	void setUp() {
		gateway = mock(IPlantaGateway.class);
		PlantaGatewayFactory factory = mock(PlantaGatewayFactory.class);
		when(factory.crearGateway(any())).thenReturn(gateway);

		// La planta informa de 0.1 toneladas disponibles (= 2000 envases de 50 gramos)
		when(gateway.getCapacidadDisponible(hoy)).thenReturn(0.1);

		contenedorService = new ContenedorService(contenedorRepository);
		PlantaService plantaService = new PlantaService(plantaRepository, registroPlantaRepository, factory);
		asignacionService = new AsignacionService(contenedorService, plantaService, asignacionRepository,
				plantaRepository, factory);

		personal = personalRepository.save(new PersonalEcoembes("Ana", "ana@ecoembes.com", "secret"));
		plantaRepository.save(new PlantaReciclaje(1, "PlasSB Ltd.", 0.6, TipoServicioPlanta.PLASSB));

		contenedorService.crearContenedor(1, "Gran Via 25, Bilbao", "48001", 2000);
		contenedorService.crearContenedor(2, "Calle Ercilla 15, Bilbao", "48009", 2000);
		contenedorService.crearContenedor(3, "Calle Ledesma 8, Bilbao", "48011", 2000);
		contenedorService.crearContenedor(4, "Calle sin datos", "48011", 2000);
		contenedorService.actualizarContenedor(1, hoy, 1000, EstadoContenedor.NARANJA);
		contenedorService.actualizarContenedor(2, hoy, 800, EstadoContenedor.NARANJA);
		contenedorService.actualizarContenedor(3, hoy, 500, EstadoContenedor.VERDE);
	}

	@Test
	void assignmentIsRegisteredWithTheTotalsAndThePerson() {
		Asignacion asignacion = asignacionService.asignarContenedores(personal, 1, hoy, List.of(1L, 2L));

		assertEquals(2, asignacion.getContenedores().size());
		assertEquals(1800, asignacion.getTotalEnvases());
		assertEquals("ana@ecoembes.com", asignacion.getPersonal().getEmail());
		assertEquals(1, asignacionService.getAsignaciones().size());
	}

	@Test
	void thePlantIsNotifiedWithTheTotalNumberOfContainersAndPackagings() {
		asignacionService.asignarContenedores(personal, 1, hoy, List.of(1L, 2L));

		verify(gateway).asignarContenedores(hoy, 2, 1800);
	}

	@Test
	void assignmentIsRejectedWhenThePlantHasNoCapacity() {
		// 1000 + 800 + 500 = 2300 packagings > 2000 supported by the plant
		RuntimeException e = assertThrows(RuntimeException.class,
				() -> asignacionService.asignarContenedores(personal, 1, hoy, List.of(1L, 2L, 3L)));

		assertEquals("Insufficient plant capacity", e.getMessage());
		assertTrue(asignacionService.getAsignaciones().isEmpty());
		verify(gateway, never()).asignarContenedores(any(), anyInt(), anyInt());
	}

	@Test
	void errorsOfTheExternalServiceAreNotSwallowed() {
		doThrow(new RuntimeException("Plant service unavailable")).when(gateway).asignarContenedores(hoy, 1, 1000);

		RuntimeException e = assertThrows(RuntimeException.class,
				() -> asignacionService.asignarContenedores(personal, 1, hoy, List.of(1L)));

		assertEquals("Plant service unavailable", e.getMessage());
	}

	@Test
	void containerCannotBeAssignedTwiceOnTheSameDate() {
		asignacionService.asignarContenedores(personal, 1, hoy, List.of(1L));

		RuntimeException e = assertThrows(RuntimeException.class,
				() -> asignacionService.asignarContenedores(personal, 1, hoy, List.of(1L)));

		assertEquals("Container already assigned", e.getMessage());
	}

	@Test
	void assignmentRejectsInvalidData() {
		assertThrows(IllegalArgumentException.class, () -> asignacionService.asignarContenedores(personal, 1, hoy, List.of()));
		assertThrows(IllegalArgumentException.class, () -> asignacionService.asignarContenedores(personal, 1, null, List.of(1L)));
		assertThrows(IllegalArgumentException.class, () -> asignacionService.asignarContenedores(personal, 1, hoy.plusDays(11), List.of(1L)));
		assertThrows(RuntimeException.class, () -> asignacionService.asignarContenedores(personal, 9, hoy, List.of(1L)));
		assertThrows(RuntimeException.class, () -> asignacionService.asignarContenedores(personal, 1, hoy, List.of(99L)));
		// Container 4 has never received an update from its sensor
		assertThrows(RuntimeException.class, () -> asignacionService.asignarContenedores(personal, 1, hoy, List.of(4L)));
	}
}
