package es.deusto.sd.plassb.dao;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import es.deusto.sd.plassb.entity.CapacidadDiaria;
import jakarta.persistence.LockModeType;

public interface CapacidadDiariaRepository extends JpaRepository<CapacidadDiaria, Long> {
	Optional<CapacidadDiaria> findByFecha(LocalDate fecha);

	// Recupera la capacidad de un día bloqueando su fila: dos asignaciones concurrentes del mismo día se serializan
	@Lock(LockModeType.PESSIMISTIC_WRITE)
	@Query("select c from CapacidadDiaria c where c.fecha = :fecha")
	Optional<CapacidadDiaria> findByFechaForUpdate(@Param("fecha") LocalDate fecha);
}
