package es.deusto.sd.ecoembes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

// Comprueba que el contexto de Spring arranca (entidades JPA, repositorios, servicios y factoría)
@SpringBootTest(properties = {
		"spring.datasource.url=jdbc:h2:mem:ecoembes-test;DB_CLOSE_DELAY=-1",
		"spring.jpa.hibernate.ddl-auto=create-drop"
})
class EcoembesApplicationTest {

	@Test
	void contextLoads() {
	}
}
