package es.deusto.sd.ecoembes.entity;

// Tecnología del servicio externo de una planta de reciclaje.
// La Factoría (PlantaGatewayFactory) la usa para decidir qué Service Gateway crear.
public enum TipoServicioPlanta {
	PLASSB,     // servicio REST (Spring Boot)
	CONTSOCKET  // servicio basado en sockets TCP
}
