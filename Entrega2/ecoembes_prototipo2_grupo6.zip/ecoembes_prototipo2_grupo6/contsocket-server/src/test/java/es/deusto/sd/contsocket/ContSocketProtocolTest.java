package es.deusto.sd.contsocket;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ContSocketProtocolTest {

	private ContSocketProtocol protocol;
	private final LocalDate hoy = LocalDate.now();

	@BeforeEach
	void setUp() {
		// 0.1 t/día = 2000 envases de 50 gramos
		protocol = new ContSocketProtocol(new CapacidadStore(0.1));
	}

	@Test
	void capacityOfADayWithoutAssignmentsIsTheDailyCapacity() {
		assertEquals("OK;0.1", protocol.procesar("CAPACIDAD;" + hoy));
		assertEquals("OK;0.1", protocol.procesar("CAPACIDAD;" + hoy.plusDays(10)));
	}

	@Test
	void assignmentReducesTheCapacity() {
		// 1000 envases = 0.05 t
		assertEquals("OK;0.05", protocol.procesar("ASIGNAR;" + hoy + ";2;1000"));
		assertEquals("OK;0.05", protocol.procesar("CAPACIDAD;" + hoy));
		// Otro día no se ve afectado
		assertEquals("OK;0.1", protocol.procesar("CAPACIDAD;" + hoy.plusDays(1)));
	}

	@Test
	void assignmentIsRejectedWhenItExceedsTheCapacity() {
		assertEquals("ERROR;409;Insufficient capacity", protocol.procesar("ASIGNAR;" + hoy + ";3;2300"));
		assertEquals("OK;0.1", protocol.procesar("CAPACIDAD;" + hoy));
	}

	@Test
	void exactCapacityCanBeAssigned() {
		assertEquals("OK;0.0", protocol.procesar("ASIGNAR;" + hoy + ";4;2000"));
	}

	@Test
	void invalidRequestsAreRejected() {
		assertTrue(protocol.procesar("CAPACIDAD;" + hoy.plusDays(11)).startsWith("ERROR;400"));
		assertTrue(protocol.procesar("CAPACIDAD;no-es-fecha").startsWith("ERROR;400"));
		assertTrue(protocol.procesar("ASIGNAR;" + hoy + ";0;100").startsWith("ERROR;400"));
		assertTrue(protocol.procesar("ASIGNAR;" + hoy + ";x;100").startsWith("ERROR;400"));
		assertTrue(protocol.procesar("ASIGNAR;" + hoy).startsWith("ERROR;400"));
		assertTrue(protocol.procesar("HOLA").startsWith("ERROR;400"));
		assertTrue(protocol.procesar(null).startsWith("ERROR;400"));
	}

	@Test
	void veryOldDatesHaveNoCapacity() {
		assertTrue(protocol.procesar("CAPACIDAD;" + hoy.minusDays(30)).startsWith("ERROR;404"));
	}
}
