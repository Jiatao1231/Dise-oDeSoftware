package es.deusto.sd.ecoembes.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;

import es.deusto.sd.ecoembes.dao.PlantaRepository;
import es.deusto.sd.ecoembes.dao.RegistroPlantaRepository;
import es.deusto.sd.ecoembes.entity.PlantaReciclaje;
import es.deusto.sd.ecoembes.entity.TipoServicioPlanta;
import es.deusto.sd.ecoembes.external.IPlantaGateway;
import es.deusto.sd.ecoembes.external.PlantaGatewayFactory;

@DataJpaTest
class PlantaServiceTest {

	@Autowired
	private PlantaRepository plantaRepository;

	@Autowired
	private RegistroPlantaRepository registroPlantaRepository;

	private PlantaService plantaService;
	private IPlantaGateway gateway;
	private final LocalDate hoy = LocalDate.now();

	@BeforeEach
	void setUp() {
		// El servicio externo de la planta se simula: el AppService solo conoce la interfaz del Service Gateway
		gateway = mock(IPlantaGateway.class);
		PlantaGatewayFactory factory = mock(PlantaGatewayFactory.class);
		when(factory.crearGateway(any())).thenReturn(gateway);

		plantaService = new PlantaService(plantaRepository, registroPlantaRepository, factory);
		plantaRepository.save(new PlantaReciclaje(1, "PlasSB Ltd.", 0.6, TipoServicioPlanta.PLASSB));
		plantaRepository.saveAndFlush(new PlantaReciclaje(2, "ContSocket Ltd.", 0.4, TipoServicioPlanta.CONTSOCKET));
	}

	@Test
	void capacityIsObtainedFromTheExternalServiceAndRegistered() {
		when(gateway.getCapacidadDisponible(hoy)).thenReturn(0.45);

		assertEquals(0.45, plantaService.getCapacidadDisponible(1, hoy), 0.000001);

		assertEquals(0.45, registroPlantaRepository.findByPlantaIdAndFecha(1, hoy).get().getCapacidadDisponible(), 0.000001);
	}

	@Test
	void thereIsOnlyOneRegistryPerPlantAndDate() {
		when(gateway.getCapacidadDisponible(hoy)).thenReturn(0.6, 0.5);

		plantaService.getCapacidadDisponible(1, hoy);
		plantaService.getCapacidadDisponible(1, hoy);

		assertEquals(1, registroPlantaRepository.count());
		assertEquals(0.5, registroPlantaRepository.findByPlantaIdAndFecha(1, hoy).get().getCapacidadDisponible(), 0.000001);
	}

	@Test
	void capacityRejectsUnknownPlantsAndDatesBeyondTenDays() {
		assertThrows(RuntimeException.class, () -> plantaService.getCapacidadDisponible(9, hoy));
		assertThrows(IllegalArgumentException.class, () -> plantaService.getCapacidadDisponible(1, hoy.plusDays(11)));
		assertThrows(IllegalArgumentException.class, () -> plantaService.getCapacidadDisponible(1, null));
	}

	@Test
	void externalServiceErrorsArePropagated() {
		when(gateway.getCapacidadDisponible(hoy)).thenThrow(new RuntimeException("Plant service unavailable"));

		RuntimeException e = assertThrows(RuntimeException.class, () -> plantaService.getCapacidadDisponible(1, hoy));
		assertEquals("Plant service unavailable", e.getMessage());
	}

	@Test
	void plantsAreReturnedSortedById() {
		assertEquals(2, plantaService.getPlantas().size());
		assertEquals("PlasSB Ltd.", plantaService.getPlantas().get(0).getNombre());
		assertEquals(TipoServicioPlanta.CONTSOCKET, plantaService.getPlantaById(2).getTipoServicio());
	}
}
