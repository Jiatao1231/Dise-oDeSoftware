package es.deusto.sd.ecoembes.service;

import java.time.LocalDate;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import es.deusto.sd.ecoembes.dao.AsignacionRepository;
import es.deusto.sd.ecoembes.dao.PlantaRepository;
import es.deusto.sd.ecoembes.entity.Asignacion;
import es.deusto.sd.ecoembes.entity.Contenedor;
import es.deusto.sd.ecoembes.entity.PersonalEcoembes;
import es.deusto.sd.ecoembes.entity.PlantaReciclaje;
import es.deusto.sd.ecoembes.entity.RegistroContenedor;
import es.deusto.sd.ecoembes.external.IPlantaGateway;
import es.deusto.sd.ecoembes.external.PlantaGatewayFactory;

@Service
public class AsignacionService {

	private static final Logger logger = LoggerFactory.getLogger(AsignacionService.class);

	private final ContenedorService contenedorService;
	private final PlantaService plantaService;
	private final AsignacionRepository asignacionRepository;
	private final PlantaRepository plantaRepository;
	private final PlantaGatewayFactory gatewayFactory;

	public AsignacionService(ContenedorService contenedorService, PlantaService plantaService,
			AsignacionRepository asignacionRepository, PlantaRepository plantaRepository,
			PlantaGatewayFactory gatewayFactory) {
		this.contenedorService = contenedorService;
		this.plantaService = plantaService;
		this.asignacionRepository = asignacionRepository;
		this.plantaRepository = plantaRepository;
		this.gatewayFactory = gatewayFactory;
	}

	// Obtener todas las asignaciones (auditoría)
	public List<Asignacion> getAsignaciones() {
		return asignacionRepository.findAllByOrderByIdAsc();
	}

	// Asigna todos los contenedores indicados a una planta de reciclaje para una fecha concreta.
	// @Transactional + bloqueo de la fila de la planta: comprobar la capacidad y registrar la asignación es
	// una unidad atómica (dos asignaciones concurrentes a la misma planta no pueden superar su capacidad).
	// Si el servicio externo de la planta rechaza la notificación se lanza una excepción y se deshace todo.
	@Transactional
	public Asignacion asignarContenedores(PersonalEcoembes personal, long plantaId, LocalDate fecha,
			List<Long> idsContenedores) {
		if (idsContenedores == null || idsContenedores.isEmpty() || fecha == null || fecha.isBefore(LocalDate.now())) {
			throw new IllegalArgumentException("Invalid assignment data");
		}

		PlantaService.validarFechaConsulta(fecha);

		Optional<PlantaReciclaje> planta = plantaRepository.findByIdForUpdate(plantaId);

		if (planta.isEmpty()) {
			throw new RuntimeException("Plant not found");
		}

		// Recupera los contenedores (se ignoran los ids repetidos)
		Set<Long> ids = new LinkedHashSet<>(idsContenedores);
		Set<Contenedor> contenedores = new LinkedHashSet<>();
		int totalEnvases = 0;

		for (Long id : ids) {
			Contenedor contenedor = (id != null) ? contenedorService.getContenedorById(id) : null;

			if (contenedor == null) {
				throw new RuntimeException("Container not found");
			}

			RegistroContenedor ultimo = contenedor.getUltimoRegistro().orElse(null);

			if (ultimo == null) {
				throw new RuntimeException("Container without fill information");
			}

			// Un contenedor solo puede asignarse una vez por fecha
			if (asignacionRepository.countByFechaAndContenedor(fecha, id) > 0) {
				throw new RuntimeException("Container already assigned");
			}

			contenedores.add(contenedor);
			totalEnvases += ultimo.getNumEnvases();
		}

		// Comprueba con el servicio externo de la planta que tiene capacidad suficiente
		// (redondeo a 6 decimales: evita errores de coma flotante en el límite exacto de la capacidad)
		double toneladas = Math.round(totalEnvases * Asignacion.PESO_MEDIO_ENVASE_TONELADAS * 1_000_000d) / 1_000_000d;

		if (toneladas > plantaService.getCapacidadDisponible(plantaId, fecha)) {
			throw new RuntimeException("Insufficient plant capacity");
		}

		// Registra la asignación junto con la persona que la realiza (auditoría)
		Asignacion asignacion = asignacionRepository
				.save(new Asignacion(fecha, totalEnvases, planta.get(), personal, contenedores));

		// Notifica a la planta (número total de contenedores y de envases) a través de su Service Gateway
		IPlantaGateway gateway = gatewayFactory.crearGateway(planta.get());
		gateway.asignarContenedores(fecha, contenedores.size(), totalEnvases);

		logger.info("Notification sent to plant '{}': {} containers, {} estimated packagings (assigned by {})",
				planta.get().getNombre(), contenedores.size(), totalEnvases, personal.getEmail());

		return asignacion;
	}
}
