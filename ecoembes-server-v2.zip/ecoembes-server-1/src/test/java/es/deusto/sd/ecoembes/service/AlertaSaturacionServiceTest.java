package es.deusto.sd.ecoembes.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.contains;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import es.deusto.sd.ecoembes.entity.EstadoContenedor;
import es.deusto.sd.ecoembes.entity.PersonalEcoembes;

class AlertaSaturacionServiceTest {

	private ContenedorService contenedorService;
	private AuthService authService;
	private EmailService emailService;
	private AlertaSaturacionService alertaService;
	private final LocalDate hoy = LocalDate.now();

	@BeforeEach
	void setUp() {
		contenedorService = new ContenedorService();
		authService = new AuthService();
		emailService = mock(EmailService.class);
		alertaService = new AlertaSaturacionService(contenedorService, authService, emailService);

		authService.addPersonal(new PersonalEcoembes("Ana", "ana@ecoembes.com", "Ana1234!"));
		authService.addPersonal(new PersonalEcoembes("Mikel", "mikel@ecoembes.com", "Mikel1234!"));

		// 5 contenedores, todos con registro de hoy en VERDE
		for (int i = 1; i <= 5; i++) {
			contenedorService.crearContenedor(i, "Calle " + i, "48001", 2000);
			contenedorService.actualizarContenedor(i, hoy, 100, EstadoContenedor.VERDE);
		}
	}

	private void ponerNivel(int cuantos, EstadoContenedor nivel) {
		for (int i = 1; i <= cuantos; i++) {
			contenedorService.actualizarContenedor(i, hoy, 1500, nivel);
		}
	}

	@Test
	void sendsAlertToAllStaffWhenMoreThan80PercentAreHigh() {
		ponerNivel(5, EstadoContenedor.NARANJA); // 100 %

		alertaService.comprobarSaturacion();

		verify(emailService).enviar(anyList(), contains("Alerta"), contains("5 de 5"));
	}

	@Test
	void countsRedContainersAsHighLevel() {
		ponerNivel(3, EstadoContenedor.NARANJA);
		contenedorService.actualizarContenedor(4, hoy, 1900, EstadoContenedor.ROJO);
		contenedorService.actualizarContenedor(5, hoy, 1900, EstadoContenedor.ROJO);

		alertaService.comprobarSaturacion();

		verify(emailService, times(1)).enviar(anyList(), anyString(), anyString());
	}

	@Test
	void doesNotSendAlertWhenExactly80PercentOrLess() {
		ponerNivel(4, EstadoContenedor.NARANJA); // 4/5 = 80 %: no es "más del 80 %"

		alertaService.comprobarSaturacion();

		verify(emailService, never()).enviar(anyList(), anyString(), anyString());
	}

	@Test
	void doesNotRepeatAlertWhileSaturationContinues() {
		ponerNivel(5, EstadoContenedor.NARANJA);

		alertaService.comprobarSaturacion();
		alertaService.comprobarSaturacion();
		alertaService.comprobarSaturacion();

		verify(emailService, times(1)).enviar(anyList(), anyString(), anyString());
	}

	@Test
	void alertsAgainAfterSituationNormalizes() {
		ponerNivel(5, EstadoContenedor.NARANJA);
		alertaService.comprobarSaturacion();

		ponerNivel(5, EstadoContenedor.VERDE); // se vacían los contenedores
		alertaService.comprobarSaturacion();

		ponerNivel(5, EstadoContenedor.NARANJA); // nueva saturación
		alertaService.comprobarSaturacion();

		verify(emailService, times(2)).enviar(anyList(), anyString(), anyString());
	}

	@Test
	void retriesOnNextCheckIfEmailFails() {
		ponerNivel(5, EstadoContenedor.NARANJA);
		doThrow(new RuntimeException("SMTP down")).doNothing()
				.when(emailService).enviar(anyList(), anyString(), anyString());

		alertaService.comprobarSaturacion(); // falla
		alertaService.comprobarSaturacion(); // reintenta y funciona

		verify(emailService, times(2)).enviar(anyList(), anyString(), anyString());
	}

	@Test
	void doesNothingWithoutContainers() {
		AlertaSaturacionService vacio = new AlertaSaturacionService(new ContenedorService(), authService, emailService);

		vacio.comprobarSaturacion();

		verify(emailService, never()).enviar(any(), any(), any());
	}

	@Test
	void sentAlertsAreStoredInTheHistory() {
		assertTrue(alertaService.getAlertas().isEmpty());

		ponerNivel(5, EstadoContenedor.NARANJA);
		alertaService.comprobarSaturacion();

		assertEquals(1, alertaService.getAlertas().size());
		assertEquals(5, alertaService.getAlertas().get(0).getContenedoresAltos());
		assertEquals(100.0, alertaService.getAlertas().get(0).getPorcentaje());
		assertEquals(2, alertaService.getAlertas().get(0).getDestinatarios().size());
	}

	@Test
	void failedAlertsAreNotStoredInTheHistory() {
		ponerNivel(5, EstadoContenedor.NARANJA);
		doThrow(new RuntimeException("SMTP down")).when(emailService).enviar(anyList(), anyString(), anyString());

		alertaService.comprobarSaturacion();

		assertTrue(alertaService.getAlertas().isEmpty());
	}
}
