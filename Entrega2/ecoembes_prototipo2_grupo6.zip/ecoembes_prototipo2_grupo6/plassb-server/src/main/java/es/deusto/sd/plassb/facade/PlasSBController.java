package es.deusto.sd.plassb.facade;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import es.deusto.sd.plassb.dto.AsignacionPlantaDTO;
import es.deusto.sd.plassb.dto.CapacidadDTO;
import es.deusto.sd.plassb.dto.NuevaAsignacionDTO;
import es.deusto.sd.plassb.entity.AsignacionPlanta;
import es.deusto.sd.plassb.service.PlasSBService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/plassb")
@Tag(name = "PlasSB Controller", description = "External service of the recycling plant PlasSB Ltd.: capacity and assignments")
public class PlasSBController {

	public static final String NOMBRE_PLANTA = "PlasSB Ltd.";

	private final PlasSBService plasSBService;

	public PlasSBController(PlasSBService plasSBService) {
		this.plasSBService = plasSBService;
	}

	// GET capacidad disponible de la planta en una fecha
	@Operation(
		summary = "Get the available capacity of the plant",
		description = "Returns the available capacity (in tons) of PlasSB Ltd. on a given date (declared capacity minus the assignments already received). The information is available up to 10 days in advance.",
		responses = {
			@ApiResponse(responseCode = "200", description = "OK: Capacity retrieved successfully"),
			@ApiResponse(responseCode = "400", description = "Bad Request: Invalid date"),
			@ApiResponse(responseCode = "404", description = "Not Found: No capacity declared for that date"),
			@ApiResponse(responseCode = "500", description = "Internal server error")
		}
	)
	@GetMapping("/capacidad")
	public ResponseEntity<CapacidadDTO> getCapacidad(
			@Parameter(name = "fecha", description = "Date (yyyy-MM-dd)", required = true, example = "2026-11-21")
			@RequestParam("fecha") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha) {
		try {
			double capacidad = plasSBService.getCapacidadDisponible(fecha);

			return new ResponseEntity<>(new CapacidadDTO(NOMBRE_PLANTA, fecha, capacidad), HttpStatus.OK);
		} catch (Exception e) {
			return errorResponse(e);
		}
	}

	// POST asignar contenedores a la planta (notificación enviada por Ecoembes)
	@Operation(
		summary = "Register an assignment of containers",
		description = "Registers the containers (total number of containers and estimated packagings) that Ecoembes sends to the plant on a given date. It is rejected if it exceeds the available capacity of that day.",
		responses = {
			@ApiResponse(responseCode = "201", description = "Created: Assignment registered successfully"),
			@ApiResponse(responseCode = "400", description = "Bad Request: Invalid assignment data"),
			@ApiResponse(responseCode = "404", description = "Not Found: No capacity declared for that date"),
			@ApiResponse(responseCode = "409", description = "Conflict: Insufficient capacity"),
			@ApiResponse(responseCode = "500", description = "Internal server error")
		}
	)
	@PostMapping("/asignaciones")
	public ResponseEntity<AsignacionPlantaDTO> asignarContenedores(
			@io.swagger.v3.oas.annotations.parameters.RequestBody(description = "Date, number of containers and packagings", required = true)
			@RequestBody NuevaAsignacionDTO nuevaAsignacion) {
		try {
			AsignacionPlanta asignacion = plasSBService.asignarContenedores(nuevaAsignacion.getFecha(),
					nuevaAsignacion.getNumContenedores(), nuevaAsignacion.getTotalEnvases());

			double restante = plasSBService.getCapacidadDisponible(asignacion.getFecha());

			return new ResponseEntity<>(new AsignacionPlantaDTO(asignacion.getId(), asignacion.getFecha(),
					asignacion.getNumContenedores(), asignacion.getTotalEnvases(), asignacion.getToneladas(),
					restante, asignacion.getFechaRegistro()), HttpStatus.CREATED);
		} catch (Exception e) {
			return errorResponse(e);
		}
	}

	// Traduce las excepciones lanzadas por el servicio en códigos de estado HTTP.
	private <T> ResponseEntity<T> errorResponse(Exception e) {
		if (e instanceof IllegalArgumentException) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

		String message = (e.getMessage() != null) ? e.getMessage() : "";

		switch (message) {
			case "Capacity not found":
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			case "Insufficient capacity":
				return new ResponseEntity<>(HttpStatus.CONFLICT);
			default:
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
