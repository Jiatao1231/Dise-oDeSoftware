package es.deusto.sd.ecoembes.dto;

import java.time.LocalDate;

public class CapacidadPlantaDTO {
	private long plantaId;
	private String nombre;
	private LocalDate fecha;
	private double capacidadDisponible;


	public CapacidadPlantaDTO() {
	}


	public CapacidadPlantaDTO(long plantaId, String nombre, LocalDate fecha, double capacidadDisponible) {
		this.plantaId = plantaId;
		this.nombre = nombre;
		this.fecha = fecha;
		this.capacidadDisponible = capacidadDisponible;
	}

	// Getters and setters
	public long getPlantaId() {
		return plantaId;
	}

	public void setPlantaId(long plantaId) {
		this.plantaId = plantaId;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	public double getCapacidadDisponible() {
		return capacidadDisponible;
	}

	public void setCapacidadDisponible(double capacidadDisponible) {
		this.capacidadDisponible = capacidadDisponible;
	}
}
