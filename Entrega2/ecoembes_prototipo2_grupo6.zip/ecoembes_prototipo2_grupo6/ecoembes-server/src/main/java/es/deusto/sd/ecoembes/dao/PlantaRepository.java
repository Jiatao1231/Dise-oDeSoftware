package es.deusto.sd.ecoembes.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import es.deusto.sd.ecoembes.entity.PlantaReciclaje;
import jakarta.persistence.LockModeType;

public interface PlantaRepository extends JpaRepository<PlantaReciclaje, Long> {
	List<PlantaReciclaje> findAllByOrderByIdAsc();

	// Recupera una planta bloqueando su fila. Se usa al asignar contenedores para que dos
	// asignaciones concurrentes a la misma planta se ejecuten una detrás de otra.
	@Lock(LockModeType.PESSIMISTIC_WRITE)
	@Query("select p from PlantaReciclaje p where p.id = :id")
	Optional<PlantaReciclaje> findByIdForUpdate(@Param("id") long id);
}
