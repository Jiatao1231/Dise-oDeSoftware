package es.deusto.sd.ecoembes.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import es.deusto.sd.ecoembes.entity.AlertaSaturacion;

public interface AlertaRepository extends JpaRepository<AlertaSaturacion, Long> {
	// De la más reciente a la más antigua
	List<AlertaSaturacion> findAllByOrderByFechaHoraDesc();
}
