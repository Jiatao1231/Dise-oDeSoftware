package es.deusto.sd.ecoembes.entity;

import java.time.LocalDate;
import java.util.Objects;

// Registro de la capacidad de una planta de reciclaje en una fecha concreta:
// capacidad diaria total y capacidad que queda disponible (en toneladas) tras las asignaciones de ese día
public class RegistroPlantaReciclaje {
	private LocalDate fecha;
	private double capacidadDiaria;
	private double capacidadDisponible;

	public RegistroPlantaReciclaje() { }

	public RegistroPlantaReciclaje(LocalDate fecha, double capacidadDiaria, double capacidadDisponible) {
		this.fecha = fecha;
		this.capacidadDiaria = capacidadDiaria;
		this.capacidadDisponible = capacidadDisponible;
	}

	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	public double getCapacidadDiaria() {
		return capacidadDiaria;
	}

	public void setCapacidadDiaria(double capacidadDiaria) {
		this.capacidadDiaria = capacidadDiaria;
	}

	public double getCapacidadDisponible() {
		return capacidadDisponible;
	}

	public void setCapacidadDisponible(double capacidadDisponible) {
		this.capacidadDisponible = capacidadDisponible;
	}

	// hashCode and equals (un registro por fecha)
	@Override
	public int hashCode() {
		return Objects.hash(fecha);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RegistroPlantaReciclaje other = (RegistroPlantaReciclaje) obj;
		return Objects.equals(fecha, other.fecha);
	}
}
