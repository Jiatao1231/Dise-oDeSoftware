package es.deusto.sd.ecoembes.external;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.LocalDate;
import java.util.concurrent.atomic.AtomicReference;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

// Prueba el gateway contra un servidor de sockets falso que responde siempre lo mismo y guarda la petición recibida
class ContSocketGatewayTest {

	private ServerSocket serverSocket;
	private final AtomicReference<String> respuesta = new AtomicReference<>("OK;0.4");
	private final AtomicReference<String> peticion = new AtomicReference<>();
	private final LocalDate fecha = LocalDate.of(2026, 11, 21);

	@BeforeEach
	void setUp() throws IOException {
		serverSocket = new ServerSocket(0);

		Thread hilo = new Thread(() -> {
			while (!serverSocket.isClosed()) {
				try (Socket cliente = serverSocket.accept();
						BufferedReader in = new BufferedReader(new InputStreamReader(cliente.getInputStream()));
						PrintWriter out = new PrintWriter(cliente.getOutputStream(), true)) {
					peticion.set(in.readLine());
					out.println(respuesta.get());
				} catch (IOException e) {
					// servidor cerrado al terminar el test
				}
			}
		});
		hilo.setDaemon(true);
		hilo.start();
	}

	@AfterEach
	void tearDown() throws IOException {
		serverSocket.close();
	}

	private ContSocketGateway gateway() {
		return new ContSocketGateway("localhost", serverSocket.getLocalPort());
	}

	@Test
	void capacityIsRequestedAndParsed() {
		respuesta.set("OK;0.35");

		assertEquals(0.35, gateway().getCapacidadDisponible(fecha), 0.000001);
		assertEquals("CAPACIDAD;2026-11-21", peticion.get());
	}

	@Test
	void assignmentIsSentWithTheTotals() {
		respuesta.set("OK;0.2");

		gateway().asignarContenedores(fecha, 3, 3500);

		assertEquals("ASIGNAR;2026-11-21;3;3500", peticion.get());
	}

	@Test
	void errorsOfTheServiceAreTranslated() {
		respuesta.set("ERROR;409;Insufficient capacity");
		RuntimeException e = assertThrows(RuntimeException.class, () -> gateway().asignarContenedores(fecha, 1, 10));
		assertEquals("Insufficient plant capacity", e.getMessage());

		respuesta.set("ERROR;400;Invalid request");
		assertThrows(IllegalArgumentException.class, () -> gateway().getCapacidadDisponible(fecha));

		respuesta.set("ERROR;500;Internal error");
		e = assertThrows(RuntimeException.class, () -> gateway().getCapacidadDisponible(fecha));
		assertEquals("Plant service unavailable", e.getMessage());
	}

	@Test
	void unreachableServiceIsReportedAsUnavailable() throws IOException {
		int puerto = serverSocket.getLocalPort();
		serverSocket.close();

		RuntimeException e = assertThrows(RuntimeException.class,
				() -> new ContSocketGateway("localhost", puerto).getCapacidadDisponible(fecha));

		assertEquals("Plant service unavailable", e.getMessage());
	}
}
