package es.deusto.sd.ecoembes.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

// Envía correos electrónicos. Si no hay servidor SMTP configurado (spring.mail.host),
// el correo se simula escribiéndolo en el log, para que el prototipo funcione sin configuración.
@Service
public class EmailService {

	private static final Logger logger = LoggerFactory.getLogger(EmailService.class);

	// JavaMailSender solo existe como bean si se ha configurado spring.mail.host
	private final ObjectProvider<JavaMailSender> mailSenderProvider;
	private final String remitente;

	public EmailService(ObjectProvider<JavaMailSender> mailSenderProvider,
			@Value("${ecoembes.alertas.email.remitente:alertas@ecoembes.com}") String remitente) {
		this.mailSenderProvider = mailSenderProvider;
		this.remitente = remitente;
	}

	// Envía un correo a una lista de destinatarios. Lanza una excepción si el servidor SMTP falla.
	public void enviar(List<String> destinatarios, String asunto, String texto) {
		if (destinatarios == null || destinatarios.isEmpty()) {
			throw new IllegalArgumentException("No recipients");
		}

		JavaMailSender mailSender = mailSenderProvider.getIfAvailable();

		if (mailSender == null) {
			logger.warn("SMTP no configurado: correo simulado.\n  De: {}\n  Para: {}\n  Asunto: {}\n  Texto: {}",
					remitente, destinatarios, asunto, texto);
			return;
		}

		SimpleMailMessage mensaje = new SimpleMailMessage();
		mensaje.setFrom(remitente);
		mensaje.setTo(destinatarios.toArray(new String[0]));
		mensaje.setSubject(asunto);
		mensaje.setText(texto);

		mailSender.send(mensaje);
		logger.info("Correo enviado a {} destinatarios: {}", destinatarios.size(), asunto);
	}
}
