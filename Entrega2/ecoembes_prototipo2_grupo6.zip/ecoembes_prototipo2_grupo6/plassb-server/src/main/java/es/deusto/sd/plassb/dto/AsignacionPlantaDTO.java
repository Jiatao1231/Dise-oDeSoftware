package es.deusto.sd.plassb.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class AsignacionPlantaDTO {
	private long id;
	private LocalDate fecha;
	private int numContenedores;
	private int totalEnvases;
	private double toneladas;
	private double capacidadRestante;
	private LocalDateTime fechaRegistro;

	public AsignacionPlantaDTO() { }

	public AsignacionPlantaDTO(long id, LocalDate fecha, int numContenedores, int totalEnvases, double toneladas,
			double capacidadRestante, LocalDateTime fechaRegistro) {
		this.id = id;
		this.fecha = fecha;
		this.numContenedores = numContenedores;
		this.totalEnvases = totalEnvases;
		this.toneladas = toneladas;
		this.capacidadRestante = capacidadRestante;
		this.fechaRegistro = fechaRegistro;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	public int getNumContenedores() {
		return numContenedores;
	}

	public void setNumContenedores(int numContenedores) {
		this.numContenedores = numContenedores;
	}

	public int getTotalEnvases() {
		return totalEnvases;
	}

	public void setTotalEnvases(int totalEnvases) {
		this.totalEnvases = totalEnvases;
	}

	public double getToneladas() {
		return toneladas;
	}

	public void setToneladas(double toneladas) {
		this.toneladas = toneladas;
	}

	public double getCapacidadRestante() {
		return capacidadRestante;
	}

	public void setCapacidadRestante(double capacidadRestante) {
		this.capacidadRestante = capacidadRestante;
	}

	public LocalDateTime getFechaRegistro() {
		return fechaRegistro;
	}

	public void setFechaRegistro(LocalDateTime fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}
}
