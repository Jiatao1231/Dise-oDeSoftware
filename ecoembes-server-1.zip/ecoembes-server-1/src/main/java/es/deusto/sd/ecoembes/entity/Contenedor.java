package es.deusto.sd.ecoembes.entity;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;

public class Contenedor {
	private long id;
	private String ubicacion;
	private String codigoPostal;
	private int capacidadInicial;
	private List<RegistroContenedor> registros = new CopyOnWriteArrayList<>(); // Lista segura de hilos: se comparte entre los hilos que atienden las peticiones HTTP

	public Contenedor() { }

	public Contenedor(long id, String ubicacion, String codigoPostal, int capacidadInicial) {
		this.id = id;
		this.ubicacion = ubicacion;
		this.codigoPostal = codigoPostal;
		this.capacidadInicial = capacidadInicial;
	}

	
	// Añade la actualización diaria del sensor. 
	// Solo se mantiene una actualización por día: si ya había una para esa fecha, se reemplaza.
	public synchronized void addRegistro(RegistroContenedor registro) {
		registros.removeIf(r -> r.getFecha().equals(registro.getFecha()));
		registros.add(registro);
	}

	// obtiene la actualización del sensor para una fecha concreta
	public Optional<RegistroContenedor> getRegistro(LocalDate fecha) {
		return registros.stream().filter(r -> r.getFecha().equals(fecha)).findFirst();
	}

	// obtiene la última actualización del sensor (la más reciente)
	public Optional<RegistroContenedor> getUltimoRegistro() {
		return registros.stream().max((r1, r2) -> r1.getFecha().compareTo(r2.getFecha()));
	}
	
	// Getters and setters
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getUbicacion() {
		return ubicacion;
	}

	public void setUbicacion(String ubicacion) {
		this.ubicacion = ubicacion;
	}

	public String getCodigoPostal() {
		return codigoPostal;
	}

	public void setCodigoPostal(String codigoPostal) {
		this.codigoPostal = codigoPostal;
	}

	public int getCapacidadInicial() {
		return capacidadInicial;
	}

	public void setCapacidadInicial(int capacidadInicial) {
		this.capacidadInicial = capacidadInicial;
	}

	public List<RegistroContenedor> getRegistros() {
		return registros;
	}

	public void setRegistros(List<RegistroContenedor> registros) {
		this.registros = registros;
	}

	// hashCode and equals
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Contenedor other = (Contenedor) obj;
		return id == other.id;
	}
}
