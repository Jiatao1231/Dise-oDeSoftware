package es.deusto.sd.ecoembes.facade;

import java.time.LocalDate;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import es.deusto.sd.ecoembes.dto.AlertaDTO;
import es.deusto.sd.ecoembes.dto.SolicitudAlertaDTO;
import es.deusto.sd.ecoembes.service.AlertaService;
import es.deusto.sd.ecoembes.service.AuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/ecoembes")
@Tag(name = "Alertas Controller", description = "Operations related to saturation alerts and email notifications")
public class AlertaController {

    private final AlertaService alertaService;
    private final AuthService authService;

    public AlertaController(AlertaService alertaService, AuthService authService) {
        this.alertaService = alertaService;
        this.authService = authService;
    }

    @Operation(
        summary = "Check and issue saturation alert",
        description = "Evaluates container fill levels. If more than 80% are full/orange/red, sends email alerts to Ecoembes staff.",
        responses = {
            @ApiResponse(responseCode = "200", description = "OK: Alert generated and notifications sent"),
            @ApiResponse(responseCode = "400", description = "Bad Request: Invalid parameters or empty container list"),
            @ApiResponse(responseCode = "401", description = "Unauthorized: User not authenticated"),
            @ApiResponse(responseCode = "409", description = "Conflict: Fill level threshold not reached"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
        }
    )
    @PostMapping("/alertas/saturacion")
    public ResponseEntity<AlertaDTO> comprobarYNotificarSaturacion(
            @Parameter(name = "fecha", description = "Date to evaluate (yyyy-MM-dd)", required = false)
            @RequestParam(name = "fecha", required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha,
            @Parameter(name = "token", description = "Authorization token", required = true)
            @RequestParam("token") String token,
            @RequestBody(required = false) SolicitudAlertaDTO solicitud) {
        try {
            if (authService.getPersonalByToken(token) == null) {
                return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
            }

            double umbral = (solicitud != null && solicitud.getUmbralPorcentaje() > 0) 
                            ? solicitud.getUmbralPorcentaje() 
                            : 80.0;

            AlertaDTO alerta = alertaService.procesarAlertaSaturacion(fecha, umbral);
            return new ResponseEntity<>(alerta, HttpStatus.OK);
        } catch (IllegalStateException e) {
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Operation(
        summary = "Get alert history",
        description = "Returns all issued saturation alerts",
        responses = {
            @ApiResponse(responseCode = "200", description = "OK: List of alerts retrieved successfully"),
            @ApiResponse(responseCode = "204", description = "No Content: No alerts registered"),
            @ApiResponse(responseCode = "401", description = "Unauthorized: User not authenticated"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
        }
    )
    @GetMapping("/alertas")
    public ResponseEntity<List<AlertaDTO>> getHistorialAlertas(
            @Parameter(name = "token", description = "Authorization token", required = true)
            @RequestParam("token") String token) {
        try {
            if (authService.getPersonalByToken(token) == null) {
                return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
            }

            List<AlertaDTO> alertas = alertaService.getHistorialAlertas();
            if (alertas.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(alertas, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}