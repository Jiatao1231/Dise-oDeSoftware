# Ecoembes Server — Prototipo 1

Primera versión del **Servidor Ecoembes** (Diseño de Software, Universidad de Deusto). Sigue la misma estructura que `auctions-server-1`: Spring Boot + Gradle, sin persistencia (datos y sesiones en memoria) y toda la funcionalidad simulada en la capa de servicios.

Patrones: **Façade** (`facade`), **Application Service** (`service`), **DTO** (`dto`) y **State Management** (mapa de tokens en `AuthService`).

## Estructura

| Paquete | Contenido |
|:--|:--|
| `facade` | `AuthController`, `EcoembesController` (fachada REST + Swagger) |
| `service` | `AuthService`, `ContenedorService`, `PlantaService`, `AsignacionService` |
| `dto` | DTOs de entrada/salida de la API |
| `entity` | `Contenedor`, `RegistroContenedor`, `EstadoContenedor`, `PlantaReciclaje`, `RegistroPlantaReciclaje`, `PersonalEcoembes`, `Asignacion` |

## API REST

El `token` devuelto por el login se envía como parámetro `token` en el resto de operaciones (en `logout` va como cuerpo de texto plano, igual que en Auctions).

| Método | Endpoint | Descripción | Respuestas |
|:--|:--|:--|:--|
| POST | `/auth/login` | Login (body: `{email, password}`), devuelve token | 200, 401 |
| POST | `/auth/logout` | Logout (body: token en texto plano) | 204, 401 |
| GET | `/ecoembes/contenedores?token` | Información actualizada de todos los contenedores | 200, 204, 401 |
| POST | `/ecoembes/contenedores?token` | Crea un contenedor (body: `{id, ubicacion, codigoPostal, capacidadInicial}`) | 201, 400, 401, 409 |
| POST | `/ecoembes/contenedores/{contenedorId}/registros` | Simula la actualización diaria del sensor (body: `{fecha?, numEnvases, nivelLlenado}`) | 204, 400, 404 |
| GET | `/ecoembes/contenedores/{contenedorId}/registros?fechaInicio&fechaFin&token` | Uso/estado de un contenedor entre dos fechas | 200, 204, 400, 401, 404 |
| GET | `/ecoembes/zonas/{codigoPostal}/contenedores?fecha&token` | Estado de los contenedores de una zona en una fecha | 200, 204, 400, 401 |
| GET | `/ecoembes/plantas?token` | Plantas de reciclaje | 200, 204, 401 |
| GET | `/ecoembes/plantas/capacidad?fecha&token` | Capacidad disponible (toneladas) de todas las plantas | 200, 204, 400, 401 |
| GET | `/ecoembes/plantas/{plantaId}/capacidad?fecha&token` | Capacidad disponible de una planta | 200, 400, 401, 404 |
| POST | `/ecoembes/asignaciones?token` | Asigna contenedores a una planta (body: `{plantaId, fecha, contenedores:[ids]}`) | 201, 400, 401, 404, 409 |
| GET | `/ecoembes/asignaciones?token` | Asignaciones registradas (auditoría) | 200, 204, 401 |

- Fechas en formato `yyyy-MM-dd`. `nivelLlenado`: `VERDE`, `NARANJA` o `ROJO`.
- La capacidad de las plantas sólo se puede consultar con hasta **10 días de antelación**.
- Una asignación comprueba la capacidad de la planta (1 envase ≈ 50 g) y registra quién la hizo.
- Swagger UI: <http://localhost:8081/swagger-ui/index.html> · OpenAPI: <http://localhost:8081/v3/api-docs>

## Datos de prueba (`DataInitializer`)

- Personal: `ana@ecoembes.com` / `Ana1234!`, `mikel@ecoembes.com` / `Mikel1234!`, `laura@ecoembes.com` / `Laura1234!`
- Plantas: 1 = PlasSB Ltd. (0,60 t/día), 2 = ContSocket Ltd. (0,40 t/día)
- Contenedores 1 a 8 (códigos postales 48001, 48009, 48010, 48011) con registros de los últimos 3 días.

## Ejecución

Requiere JDK 21.

```bash
./gradlew bootRun     # Windows: .\gradlew.bat bootRun
./gradlew test
```

El servidor arranca en <http://localhost:8081>.

## Simplificaciones del prototipo

- Sin persistencia: al reiniciar se pierden los datos (llega en el Prototipo 2).
- Las plantas PlasSB y ContSocket están simuladas en `PlantaService`; la notificación a la planta se escribe en el log. Los servicios externos llegan en el Prototipo 2.
- Contraseñas con SHA-1 y tokens UUID, como en Auctions.
