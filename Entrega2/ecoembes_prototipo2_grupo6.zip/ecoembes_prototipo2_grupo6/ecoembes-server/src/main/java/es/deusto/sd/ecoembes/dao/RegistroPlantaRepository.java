package es.deusto.sd.ecoembes.dao;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import es.deusto.sd.ecoembes.entity.RegistroPlantaReciclaje;

public interface RegistroPlantaRepository extends JpaRepository<RegistroPlantaReciclaje, Long> {
	Optional<RegistroPlantaReciclaje> findByPlantaIdAndFecha(long plantaId, LocalDate fecha);
}
