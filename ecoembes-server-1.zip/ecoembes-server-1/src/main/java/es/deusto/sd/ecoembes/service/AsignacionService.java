package es.deusto.sd.ecoembes.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import es.deusto.sd.ecoembes.entity.Asignacion;
import es.deusto.sd.ecoembes.entity.Contenedor;
import es.deusto.sd.ecoembes.entity.PersonalEcoembes;
import es.deusto.sd.ecoembes.entity.PlantaReciclaje;
import es.deusto.sd.ecoembes.entity.RegistroContenedor;

@Service
public class AsignacionService {

	private static final Logger logger = LoggerFactory.getLogger(AsignacionService.class);

	private final ContenedorService contenedorService;
	private final PlantaService plantaService;

	// Simular el repositorio de asignaciones
	private final Map<Long, Asignacion> asignacionRepository = new ConcurrentHashMap<>();
	private final AtomicLong nextId = new AtomicLong(1);

	public AsignacionService(ContenedorService contenedorService, PlantaService plantaService) {
		this.contenedorService = contenedorService;
		this.plantaService = plantaService;
	}

	// Obtener todas las asignaciones
	public List<Asignacion> getAsignaciones() {
		return asignacionRepository.values().stream()
				.sorted((a1, a2) -> Long.compare(a1.getId(), a2.getId()))
				.toList();
	}

	
	// Asigna todos los contenedores indicados a una planta de reciclaje para una fecha concreta.
	// El método es synchronized: comprobar la capacidad disponible de la planta y registrar la asignación
	// debe ser atómico, de lo contrario dos asignaciones concurrentes podrían pasar la comprobación y 
	// superar la capacidad de la planta.
	
	public synchronized Asignacion asignarContenedores(PersonalEcoembes personal, long plantaId, LocalDate fecha,
			List<Long> idsContenedores) {
		if (idsContenedores == null || idsContenedores.isEmpty() || fecha == null || fecha.isBefore(LocalDate.now())) {
			throw new IllegalArgumentException("Invalid assignment data");
		}

		PlantaService.validarFechaConsulta(fecha);

		PlantaReciclaje planta = plantaService.getPlantaById(plantaId);

		if (planta == null) {
			throw new RuntimeException("Plant not found");
		}

		
		// Recupera los contenedores (se ignoran los ids repetidos)
		Set<Long> ids = new LinkedHashSet<>(idsContenedores);
		List<Contenedor> contenedores = new ArrayList<>();
		int totalEnvases = 0;

		for (Long id : ids) {
			Contenedor contenedor = (id != null) ? contenedorService.getContenedorById(id) : null;

			if (contenedor == null) {
				throw new RuntimeException("Container not found");
			}

			RegistroContenedor ultimo = contenedor.getUltimoRegistro().orElse(null);

			if (ultimo == null) {
				throw new RuntimeException("Container without fill information");
			}

			if (estaAsignado(contenedor, fecha)) {
				throw new RuntimeException("Container already assigned");
			}

			contenedores.add(contenedor);
			totalEnvases += ultimo.getNumEnvases();
		}

		// Comprobar que la planta tiene capacidad suficiente para los envases de los contenedores
		double toneladas = totalEnvases * Asignacion.PESO_MEDIO_ENVASE_TONELADAS;

		if (toneladas > planta.getCapacidadDisponible(fecha)) {
			throw new RuntimeException("Insufficient plant capacity");
		}

		// Registrar la asignación junto con la persona que la realiza (auditoría)
		Asignacion asignacion = new Asignacion(nextId.getAndIncrement(), fecha, totalEnvases, planta, personal,
				contenedores);
		asignacionRepository.put(asignacion.getId(), asignacion);

		// Simular notificación a la planta de reciclaje (por ejemplo, un correo electrónico)
		logger.info("Notification to plant '{}': {} containers, {} estimated packagings (assigned by {})",
				planta.getNombre(), contenedores.size(), totalEnvases, personal.getEmail());

		return asignacion;
	}

	// Un contenedor solo puede asignarse una vez por fecha
	private boolean estaAsignado(Contenedor contenedor, LocalDate fecha) {
		return asignacionRepository.values().stream()
				.anyMatch(a -> a.getFecha().equals(fecha) && a.getContenedores().contains(contenedor));
	}
}
