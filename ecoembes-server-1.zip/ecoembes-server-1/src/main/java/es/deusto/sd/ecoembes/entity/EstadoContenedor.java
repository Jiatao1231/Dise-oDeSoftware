package es.deusto.sd.ecoembes.entity;

public enum EstadoContenedor {
	VERDE,   // contenedor con espacio disponible
	NARANJA, // Espacio limitado
	ROJO     // contenedor lleno
}
