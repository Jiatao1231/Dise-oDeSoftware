# Prototipo 2 — Diseño del API de los servicios externos de las plantas de reciclaje

Cada planta expone **2 operaciones**: *consultar su capacidad disponible en una fecha* y *asignarle contenedores*.
El Servidor Ecoembes las invoca a través de la interfaz `IPlantaGateway` (patrón Service Gateway), por lo que el
`AppService` no conoce la tecnología de cada planta.

| Operación del Gateway | PlasSB Ltd. (REST) | ContSocket Ltd. (sockets) |
|:--|:--|:--|
| `getCapacidadDisponible(fecha)` | `GET /plassb/capacidad?fecha` | `CAPACIDAD;fecha` |
| `asignarContenedores(fecha, numContenedores, totalEnvases)` | `POST /plassb/asignaciones` | `ASIGNAR;fecha;numContenedores;totalEnvases` |

Reglas comunes: fechas `yyyy-MM-dd`; capacidad en **toneladas**; la capacidad solo se informa con **10 días de antelación**;
1 envase ≈ 50 g (0,00005 t). Una asignación se rechaza si sus toneladas superan la capacidad disponible de ese día.

---

## 1. PlasSB Ltd. — Servidor Spring Boot (JPA + H2), puerto 8084

### 1.1 Consulta de la capacidad disponible
* **Endpoint:** `/plassb/capacidad`
* **Método HTTP:** `GET`
* **Parámetros (query):** `fecha` (obligatorio, `yyyy-MM-dd`)
* **Cuerpo:** no aplica
* **Retorno `200 OK`:**
```json
{ "planta": "PlasSB Ltd.", "fecha": "2026-11-21", "capacidadDisponible": 0.55 }
```
* **Otras respuestas:**
  * `400 Bad Request`: fecha ausente, mal formada o con más de 10 días de antelación
  * `404 Not Found`: no hay capacidad declarada para esa fecha
  * `500 Internal Server Error`: error interno

### 1.2 Asignación de contenedores a la planta
* **Endpoint:** `/plassb/asignaciones`
* **Método HTTP:** `POST`
* **Parámetros:** ninguno
* **Cuerpo (`application/json`):**
```json
{ "fecha": "2026-11-21", "numContenedores": 3, "totalEnvases": 3500 }
```
* **Retorno `201 Created`:**
```json
{ "id": 1, "fecha": "2026-11-21", "numContenedores": 3, "totalEnvases": 3500,
  "toneladas": 0.175, "capacidadRestante": 0.425, "fechaRegistro": "2026-11-20T10:15:30" }
```
* **Otras respuestas:**
  * `400 Bad Request`: datos no válidos (`numContenedores` o `totalEnvases` ≤ 0, fecha inválida)
  * `404 Not Found`: no hay capacidad declarada para esa fecha
  * `409 Conflict`: la asignación supera la capacidad disponible
  * `500 Internal Server Error`: error interno

---

## 2. ContSocket Ltd. — Servidor de sockets TCP (persistencia en memoria), puerto 9090

Protocolo de texto: **una línea por mensaje**, campos separados por `;`, **una petición por conexión**
(el cliente abre el socket, envía una línea, lee una línea de respuesta y cierra).

### 2.1 Consulta de la capacidad disponible
* **Petición:** `CAPACIDAD;<fecha>` → ejemplo: `CAPACIDAD;2026-11-21`
* **Respuesta OK:** `OK;<toneladas disponibles>` → ejemplo: `OK;0.4`
* **Respuestas de error:**
  * `ERROR;400;<mensaje>`: fecha mal formada o con más de 10 días de antelación, o petición inválida
  * `ERROR;404;Capacity not found`: fecha demasiado antigua, sin capacidad declarada
  * `ERROR;500;Internal error`

### 2.2 Asignación de contenedores a la planta
* **Petición:** `ASIGNAR;<fecha>;<numContenedores>;<totalEnvases>` → ejemplo: `ASIGNAR;2026-11-21;3;3500`
* **Respuesta OK:** `OK;<toneladas que quedan ese día>` → ejemplo: `OK;0.225`
* **Respuestas de error:**
  * `ERROR;400;<mensaje>`: datos no válidos
  * `ERROR;404;Capacity not found`
  * `ERROR;409;Insufficient capacity`: supera la capacidad disponible
  * `ERROR;500;Internal error`

---

## 3. Traducción de errores en el Servidor Ecoembes

Los gateways convierten las respuestas de las plantas en excepciones que la fachada traduce a HTTP:

| Respuesta de la planta | Excepción del gateway | HTTP en Ecoembes |
|:--|:--|:--|
| REST `400` / socket `ERROR;400` | `IllegalArgumentException` | 400 |
| REST `409` / socket `ERROR;409` | `RuntimeException("Insufficient plant capacity")` | 409 |
| Cualquier otro error, o planta caída | `RuntimeException("Plant service unavailable")` | 500 |

## 4. Cambios del diagrama de clases respecto al Prototipo 1

* **DAO:** `ContenedorRepository`, `PlantaRepository`, `RegistroPlantaRepository`, `PersonalRepository`, `AsignacionRepository`, `AlertaRepository` (paquete `dao`).
* **Service Gateway:** interfaz `IPlantaGateway` con las implementaciones `PlasSBGateway` (REST) y `ContSocketGateway` (sockets), paquete `external`.
* **Factoría:** `PlantaGatewayFactory.crearGateway(PlantaReciclaje)`; único sitio con `switch` sobre `TipoServicioPlanta`.
* **`PlantaReciclaje`:** nuevo atributo `tipoServicio` (enum `TipoServicioPlanta`: `PLASSB`, `CONTSOCKET`). Su capacidad ya no se calcula localmente: la informa el servicio externo.
* **`RegistroPlantaReciclaje`:** ahora guarda `fecha` y `capacidadDisponible` (última capacidad consultada) y es entidad JPA ligada a la planta.
* **Entidades JPA:** `Contenedor`, `RegistroContenedor`, `PlantaReciclaje`, `RegistroPlantaReciclaje`, `PersonalEcoembes`, `Asignacion` (`Set<Contenedor>`, N:M), `AlertaSaturacion`.
* **`AuthService`, `ContenedorService`, `PlantaService`, `AsignacionService`, `AlertaSaturacionService`:** usan los DAO; `PlantaService` y `AsignacionService` usan la Factoría y `IPlantaGateway`.
* Se eliminan `addPersonal` y `addPlanta` (la carga inicial la hace `DataInitializer` con los DAO).
* **Servidores externos:** `PlasSBController` → `PlasSBService` → `CapacidadDiariaRepository` / `AsignacionPlantaRepository`; `ContSocketServer` → `ContSocketProtocol` → `CapacidadStore` (memoria).
