package es.deusto.sd.plassb.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

// Asignación recibida desde Ecoembes: contenedores y envases que la planta procesará en una fecha
@Entity
public class AsignacionPlanta {

	// Peso medio de un envase en toneladas (50 gramos)
	public static final double PESO_MEDIO_ENVASE_TONELADAS = 0.00005;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(nullable = false)
	private LocalDate fecha;

	private int numContenedores;
	private int totalEnvases;
	private double toneladas;
	private LocalDateTime fechaRegistro;

	public AsignacionPlanta() { }

	public AsignacionPlanta(LocalDate fecha, int numContenedores, int totalEnvases) {
		this.fecha = fecha;
		this.numContenedores = numContenedores;
		this.totalEnvases = totalEnvases;
		this.toneladas = totalEnvases * PESO_MEDIO_ENVASE_TONELADAS;
		this.fechaRegistro = LocalDateTime.now();
	}

	public Long getId() {
		return id;
	}

	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	public int getNumContenedores() {
		return numContenedores;
	}

	public void setNumContenedores(int numContenedores) {
		this.numContenedores = numContenedores;
	}

	public int getTotalEnvases() {
		return totalEnvases;
	}

	public void setTotalEnvases(int totalEnvases) {
		this.totalEnvases = totalEnvases;
	}

	public double getToneladas() {
		return toneladas;
	}

	public void setToneladas(double toneladas) {
		this.toneladas = toneladas;
	}

	public LocalDateTime getFechaRegistro() {
		return fechaRegistro;
	}

	public void setFechaRegistro(LocalDateTime fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}
}
