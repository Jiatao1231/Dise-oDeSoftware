package es.deusto.sd.contsocket;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

// Servidor de ContSocket Ltd.: servicio externo de una planta de reciclaje basado en sockets TCP.
// Un hilo atiende cada conexión (un mensaje por conexión) y la información se guarda en memoria.
public class ContSocketServer {

	private final int port;
	private final ContSocketProtocol protocol;
	private final ExecutorService pool = Executors.newCachedThreadPool();
	private volatile boolean running = true;
	private ServerSocket serverSocket;

	public ContSocketServer(int port, ContSocketProtocol protocol) {
		this.port = port;
		this.protocol = protocol;
	}

	public void start() throws IOException {
		serverSocket = new ServerSocket(port);
		System.out.println("ContSocket Ltd. server listening on port " + serverSocket.getLocalPort());

		while (running) {
			try {
				Socket client = serverSocket.accept();
				pool.execute(() -> atender(client));
			} catch (IOException e) {
				if (running) {
					System.err.println("Error accepting connection: " + e.getMessage());
				}
			}
		}
	}

	public void stop() throws IOException {
		running = false;
		pool.shutdown();

		if (serverSocket != null) {
			serverSocket.close();
		}
	}

	// Lee un mensaje del cliente, lo procesa y devuelve la respuesta
	private void atender(Socket client) {
		try (client;
				BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream(), StandardCharsets.UTF_8));
				PrintWriter out = new PrintWriter(client.getOutputStream(), true, StandardCharsets.UTF_8)) {
			client.setSoTimeout(5000);

			String request = in.readLine();
			String response = protocol.procesar(request);

			System.out.println("Request: " + request + "  ->  Response: " + response);
			out.println(response);
		} catch (IOException e) {
			System.err.println("Error serving client: " + e.getMessage());
		}
	}

	public static void main(String[] args) throws IOException {
		Properties properties = new Properties();

		try (InputStream is = ContSocketServer.class.getResourceAsStream("/contsocket.properties")) {
			if (is != null) {
				properties.load(is);
			}
		}

		int port = Integer.parseInt(properties.getProperty("contsocket.port", "9090"));
		double capacidadDiaria = Double.parseDouble(properties.getProperty("contsocket.capacidad-diaria", "0.40"));

		new ContSocketServer(port, new ContSocketProtocol(new CapacidadStore(capacidadDiaria))).start();
	}
}
