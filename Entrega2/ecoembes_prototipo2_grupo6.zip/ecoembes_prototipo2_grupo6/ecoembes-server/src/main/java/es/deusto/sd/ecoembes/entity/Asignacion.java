package es.deusto.sd.ecoembes.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;

@Entity
public class Asignacion {

	// Peso medio de un envase en toneladas (50 gramos)
	public static final double PESO_MEDIO_ENVASE_TONELADAS = 0.00005;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Column(nullable = false)
	private LocalDate fecha;

	private int totalEnvases;

	private LocalDateTime fechaRegistro;

	@ManyToOne
	@JoinColumn(name = "planta_id", nullable = false)
	private PlantaReciclaje planta;

	// Persona que realizó la asignación (auditoría)
	@ManyToOne
	@JoinColumn(name = "personal_id", nullable = false)
	private PersonalEcoembes personal;

	// Un Set evita cargar dos "bags" a la vez (Contenedor.registros ya es una lista EAGER)
	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "asignacion_contenedor",
			joinColumns = @JoinColumn(name = "asignacion_id"),
			inverseJoinColumns = @JoinColumn(name = "contenedor_id"))
	private Set<Contenedor> contenedores = new LinkedHashSet<>();

	public Asignacion() { }

	public Asignacion(LocalDate fecha, int totalEnvases, PlantaReciclaje planta, PersonalEcoembes personal,
			Set<Contenedor> contenedores) {
		this.fecha = fecha;
		this.totalEnvases = totalEnvases;
		this.fechaRegistro = LocalDateTime.now();
		this.planta = planta;
		this.personal = personal;
		this.contenedores = contenedores;
	}

	// Getters and setters
	public double getToneladas() {
		return totalEnvases * PESO_MEDIO_ENVASE_TONELADAS;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	public int getTotalEnvases() {
		return totalEnvases;
	}

	public void setTotalEnvases(int totalEnvases) {
		this.totalEnvases = totalEnvases;
	}

	public LocalDateTime getFechaRegistro() {
		return fechaRegistro;
	}

	public void setFechaRegistro(LocalDateTime fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

	public PlantaReciclaje getPlanta() {
		return planta;
	}

	public void setPlanta(PlantaReciclaje planta) {
		this.planta = planta;
	}

	public PersonalEcoembes getPersonal() {
		return personal;
	}

	public void setPersonal(PersonalEcoembes personal) {
		this.personal = personal;
	}

	public Set<Contenedor> getContenedores() {
		return contenedores;
	}

	public void setContenedores(Set<Contenedor> contenedores) {
		this.contenedores = contenedores;
	}

	// hashCode and equals
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Asignacion other = (Asignacion) obj;
		return id == other.id;
	}
}
