package es.deusto.sd.ecoembes.entity;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.apache.commons.codec.digest.DigestUtils;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class PersonalEcoembes {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(nullable = false)
	private String nombre;

	@Column(nullable = false)
	private String password;

	@Column(nullable = false, unique = true)
	private String email;

	// Asignaciones realizadas por esta persona (auditoría). Se carga bajo demanda.
	@OneToMany(mappedBy = "personal", fetch = FetchType.LAZY)
	private List<Asignacion> asignaciones = new ArrayList<>();

	public PersonalEcoembes() { }

	public PersonalEcoembes(String nombre, String email, String password) {
		this.nombre = nombre;
		this.email = email;
		// Contraseña almacenada como un hash SHA-1 (no se guarda la contraseña en texto plano)
		this.password = DigestUtils.sha1Hex(password);
	}

	// Comprueba si una contraseña es correcta comparando el hash SHA-1 de la contraseña
	// proporcionada con el hash almacenado (la contraseña en texto plano nunca se guarda).
	public boolean checkPassword(String password) {
		return this.password.equals(DigestUtils.sha1Hex(password));
	}

	public Long getId() {
		return id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	// Note: there is no getPassword() on purpose (the stored hash is never exposed).
	public void setPassword(String password) {
		this.password = DigestUtils.sha1Hex(password);
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<Asignacion> getAsignaciones() {
		return asignaciones;
	}

	public void setAsignaciones(List<Asignacion> asignaciones) {
		this.asignaciones = asignaciones;
	}

	// hashCode and equals based on the business key (email), which is unique and non-null
	@Override
	public int hashCode() {
		return Objects.hash(email);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PersonalEcoembes other = (PersonalEcoembes) obj;
		return Objects.equals(email, other.email);
	}
}
