package es.deusto.sd.ecoembes.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Service;

import es.deusto.sd.ecoembes.dao.PersonalRepository;
import es.deusto.sd.ecoembes.entity.PersonalEcoembes;

@Service
public class AuthService {

	private final PersonalRepository personalRepository;

	// Almacena el estado de la sesión del personal que ha iniciado sesión (estado del servidor).
	// ConcurrentHashMap: se accede desde los hilos que atienden las peticiones HTTP concurrentes.
	private final Map<String, PersonalEcoembes> tokenStore = new ConcurrentHashMap<>();

	public AuthService(PersonalRepository personalRepository) {
		this.personalRepository = personalRepository;
	}

	// Metodo de inicio de sesión que comprueba si la persona existe en la BD y valida la contraseña
	public Optional<String> login(String email, String password) {
		if (email == null || password == null) {
			return Optional.empty();
		}

		Optional<PersonalEcoembes> personal = personalRepository.findByEmail(email);

		if (personal.isPresent() && personal.get().checkPassword(password)) {
			String token = generateToken();       // Genera un token único y no adivinable para la sesión
			tokenStore.put(token, personal.get()); // Almacena el token en el estado del servidor

			return Optional.of(token);
		} else {
			return Optional.empty();
		}
	}

	// Metodo de cierre de sesión que elimina el token del estado del servidor
	public Optional<Boolean> logout(String token) {
		if (token != null && tokenStore.containsKey(token)) {
			tokenStore.remove(token);

			return Optional.of(true);
		} else {
			return Optional.empty();
		}
	}

	// Método para obtener la persona basada en el token
	public PersonalEcoembes getPersonalByToken(String token) {
		if (token == null) {
			return null;
		}

		return tokenStore.get(token);
	}

	// Todo el personal de Ecoembes (destinatarios de las alertas)
	public List<PersonalEcoembes> getTodoElPersonal() {
		return personalRepository.findAll();
	}

	// Genera un token de sesión único y no adivinable.
	private static String generateToken() {
		return UUID.randomUUID().toString();
	}
}
