package es.deusto.sd.ecoembes.external;

import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

import es.deusto.sd.ecoembes.entity.PlantaReciclaje;
import es.deusto.sd.ecoembes.entity.TipoServicioPlanta;

class PlantaGatewayFactoryTest {

	private final PlantaGatewayFactory factory = new PlantaGatewayFactory("http://localhost:8084", "localhost", 9090);

	@Test
	void createsTheGatewayThatCorrespondsToEachPlant() {
		PlantaReciclaje plasSB = new PlantaReciclaje(1, "PlasSB Ltd.", 0.6, TipoServicioPlanta.PLASSB);
		PlantaReciclaje contSocket = new PlantaReciclaje(2, "ContSocket Ltd.", 0.4, TipoServicioPlanta.CONTSOCKET);

		assertInstanceOf(PlasSBGateway.class, factory.crearGateway(plasSB));
		assertInstanceOf(ContSocketGateway.class, factory.crearGateway(contSocket));
	}

	@Test
	void reusesTheGatewayOfTheSameTechnology() {
		PlantaReciclaje a = new PlantaReciclaje(1, "PlasSB Ltd.", 0.6, TipoServicioPlanta.PLASSB);
		PlantaReciclaje b = new PlantaReciclaje(3, "Otra planta REST", 0.5, TipoServicioPlanta.PLASSB);

		assertSame(factory.crearGateway(a), factory.crearGateway(b));
	}

	@Test
	void plantsWithoutServiceTypeAreRejected() {
		assertThrows(IllegalStateException.class, () -> factory.crearGateway(new PlantaReciclaje()));
		assertThrows(IllegalStateException.class, () -> factory.crearGateway(null));
	}
}
