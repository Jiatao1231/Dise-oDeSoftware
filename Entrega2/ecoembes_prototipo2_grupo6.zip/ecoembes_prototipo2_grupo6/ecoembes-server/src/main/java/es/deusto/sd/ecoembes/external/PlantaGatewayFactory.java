package es.deusto.sd.ecoembes.external;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import es.deusto.sd.ecoembes.entity.PlantaReciclaje;
import es.deusto.sd.ecoembes.entity.TipoServicioPlanta;

// Factoría: crea el Service Gateway que corresponde a cada planta de reciclaje.
// Es el ÚNICO sitio donde se decide el tipo concreto de gateway (switch). Para incorporar una nueva
// planta basta con añadir un valor a TipoServicioPlanta, su gateway y un "case" aquí.
@Component
public class PlantaGatewayFactory {

	private final String plasSbUrl;
	private final String contSocketHost;
	private final int contSocketPort;

	// Los gateways no tienen estado por planta: se crea uno por tecnología y se reutiliza
	private final Map<TipoServicioPlanta, IPlantaGateway> gateways = new ConcurrentHashMap<>();

	// Direcciones y puertos de los servicios externos: se leen de application.properties
	public PlantaGatewayFactory(
			@Value("${ecoembes.plantas.plassb.url}") String plasSbUrl,
			@Value("${ecoembes.plantas.contsocket.host}") String contSocketHost,
			@Value("${ecoembes.plantas.contsocket.port}") int contSocketPort) {
		this.plasSbUrl = plasSbUrl;
		this.contSocketHost = contSocketHost;
		this.contSocketPort = contSocketPort;
	}

	public IPlantaGateway crearGateway(PlantaReciclaje planta) {
		if (planta == null || planta.getTipoServicio() == null) {
			throw new IllegalStateException("Unknown plant service");
		}

		return gateways.computeIfAbsent(planta.getTipoServicio(), this::nuevoGateway);
	}

	private IPlantaGateway nuevoGateway(TipoServicioPlanta tipo) {
		switch (tipo) {
			case PLASSB:
				return new PlasSBGateway(plasSbUrl);
			case CONTSOCKET:
				return new ContSocketGateway(contSocketHost, contSocketPort);
			default:
				throw new IllegalStateException("Unknown plant service");
		}
	}
}
