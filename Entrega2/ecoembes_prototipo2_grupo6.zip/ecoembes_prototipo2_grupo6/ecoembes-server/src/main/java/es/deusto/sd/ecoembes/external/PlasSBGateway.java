package es.deusto.sd.ecoembes.external;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.LocalDate;
import java.util.Locale;
import java.util.Map;

import tools.jackson.databind.ObjectMapper;

// Service Gateway de PlasSB Ltd.: el servicio externo es una API REST (Spring Boot).
public class PlasSBGateway implements IPlantaGateway {

	private static final String PLANT_UNAVAILABLE = "Plant service unavailable";

	private final String baseUrl;
	private final HttpClient httpClient;
	private final ObjectMapper objectMapper;

	public PlasSBGateway(String baseUrl) {
		this.baseUrl = baseUrl;
		// El timeout de conexión evita bloquear el hilo si el servicio externo no responde
		this.httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
		this.objectMapper = new ObjectMapper();
	}

	@SuppressWarnings("unchecked")
	@Override
	public double getCapacidadDisponible(LocalDate fecha) {
		HttpRequest request = HttpRequest.newBuilder()
				.uri(URI.create(baseUrl + "/plassb/capacidad?fecha=" + fecha))
				.timeout(Duration.ofSeconds(5))
				.GET()
				.build();

		HttpResponse<String> response = send(request);

		if (response.statusCode() == 400) {
			throw new IllegalArgumentException("Invalid date");
		}

		if (response.statusCode() != 200) {
			throw new RuntimeException(PLANT_UNAVAILABLE);
		}

		try {
			Map<String, Object> body = objectMapper.readValue(response.body(), Map.class);

			return Double.parseDouble(String.valueOf(body.get("capacidadDisponible")));
		} catch (Exception e) {
			throw new RuntimeException(PLANT_UNAVAILABLE);
		}
	}

	@Override
	public void asignarContenedores(LocalDate fecha, int numContenedores, int totalEnvases) {
		String json = String.format(Locale.ROOT, "{\"fecha\":\"%s\",\"numContenedores\":%d,\"totalEnvases\":%d}",
				fecha, numContenedores, totalEnvases);

		HttpRequest request = HttpRequest.newBuilder()
				.uri(URI.create(baseUrl + "/plassb/asignaciones"))
				.timeout(Duration.ofSeconds(5))
				.header("Content-Type", "application/json")
				.POST(HttpRequest.BodyPublishers.ofString(json))
				.build();

		HttpResponse<String> response = send(request);

		switch (response.statusCode()) {
			case 201:
				return;
			case 400:
				throw new IllegalArgumentException("Invalid assignment data");
			case 409:
				throw new RuntimeException("Insufficient plant capacity");
			default:
				throw new RuntimeException(PLANT_UNAVAILABLE);
		}
	}

	private HttpResponse<String> send(HttpRequest request) {
		try {
			return httpClient.send(request, HttpResponse.BodyHandlers.ofString());
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			throw new RuntimeException(PLANT_UNAVAILABLE);
		} catch (Exception e) {
			throw new RuntimeException(PLANT_UNAVAILABLE);
		}
	}
}
