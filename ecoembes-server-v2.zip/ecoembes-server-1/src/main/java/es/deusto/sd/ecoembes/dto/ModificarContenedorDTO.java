package es.deusto.sd.ecoembes.dto;

public class ModificarContenedorDTO {
	private String ubicacion;
	private String codigoPostal;
	private int capacidadInicial;

	public ModificarContenedorDTO() {
	}

	public ModificarContenedorDTO(String ubicacion, String codigoPostal, int capacidadInicial) {
		this.ubicacion = ubicacion;
		this.codigoPostal = codigoPostal;
		this.capacidadInicial = capacidadInicial;
	}

	public String getUbicacion() {
		return ubicacion;
	}

	public void setUbicacion(String ubicacion) {
		this.ubicacion = ubicacion;
	}

	public String getCodigoPostal() {
		return codigoPostal;
	}

	public void setCodigoPostal(String codigoPostal) {
		this.codigoPostal = codigoPostal;
	}

	public int getCapacidadInicial() {
		return capacidadInicial;
	}

	public void setCapacidadInicial(int capacidadInicial) {
		this.capacidadInicial = capacidadInicial;
	}
}
