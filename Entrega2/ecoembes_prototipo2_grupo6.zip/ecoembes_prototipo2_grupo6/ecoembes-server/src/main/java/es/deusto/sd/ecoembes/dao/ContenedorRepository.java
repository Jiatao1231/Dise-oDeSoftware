package es.deusto.sd.ecoembes.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import es.deusto.sd.ecoembes.entity.Contenedor;

public interface ContenedorRepository extends JpaRepository<Contenedor, Long> {
	List<Contenedor> findAllByOrderByIdAsc();
	List<Contenedor> findByCodigoPostalOrderByIdAsc(String codigoPostal);
}
