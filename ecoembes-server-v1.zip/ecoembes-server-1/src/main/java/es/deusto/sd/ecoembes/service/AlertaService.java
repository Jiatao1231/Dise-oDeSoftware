package es.deusto.sd.ecoembes.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import es.deusto.sd.ecoembes.dto.AlertaDTO;
import es.deusto.sd.ecoembes.entity.Contenedor;
import es.deusto.sd.ecoembes.entity.EstadoContenedor;
import es.deusto.sd.ecoembes.entity.PersonalEcoembes;

@Service
public class AlertaService {

    private final ContenedorService contenedorService;
    private final AuthService authService;
    private final List<AlertaDTO> historialAlertas = new ArrayList<>();
    private long contadorAlertas = 1;

    public AlertaService(ContenedorService contenedorService, AuthService authService) {
        this.contenedorService = contenedorService;
        this.authService = authService;
    }

    public AlertaDTO procesarAlertaSaturacion(LocalDate fechaEvaluacion, double umbralRequerido) {
        LocalDate fecha = (fechaEvaluacion != null) ? fechaEvaluacion : LocalDate.now();

        List<Contenedor> contenedores = contenedorService.getContenedores();
        if (contenedores.isEmpty()) {
            throw new IllegalArgumentException("No containers available to calculate alert state");
        }

        int total = contenedores.size();
        int saturados = 0;

        for (Contenedor c : contenedores) {
            var optReg = c.getRegistro(fecha);
            if (optReg.isPresent()) {
                EstadoContenedor estado = optReg.get().getNivelLlenado();
                if (estado == EstadoContenedor.NARANJA || estado == EstadoContenedor.ROJO) {
                    saturados++;
                }
            }
        }

        double porcentajeCalculado = ((double) saturados / total) * 100.0;

        if (porcentajeCalculado < umbralRequerido) {
            throw new IllegalStateException("Threshold not exceeded");
        }

        List<PersonalEcoembes> personal = authService.getTodoElPersonal();
        int destinatariosNotificados = personal.size();

        AlertaDTO alerta = new AlertaDTO(
            contadorAlertas++,
            fecha,
            Math.round(porcentajeCalculado * 100.0) / 100.0,
            total,
            saturados,
            "NOTIFICADA",
            LocalDateTime.now(),
            destinatariosNotificados
        );

        historialAlertas.add(alerta);
        return alerta;
    }

    public List<AlertaDTO> getHistorialAlertas() {
        return new ArrayList<>(historialAlertas);
    }
}