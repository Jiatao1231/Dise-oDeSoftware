package es.deusto.sd.ecoembes.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Service;

import es.deusto.sd.ecoembes.entity.PlantaReciclaje;

@Service
public class PlantaService {

	// Inicializar la variable para que la capacidad de las plantas solo esté disponible con 10 días de antelación
	public static final int DIAS_ANTELACION = 10;
	
	// Simulando el repositorio de plantas de reciclaje.
	// En este primer prototipo la información de las plantas (PlasSB Ltd. y ContSocket Ltd.)
	// se simula aquí.
	private final Map<Long, PlantaReciclaje> plantaRepository = new ConcurrentHashMap<>();

	// Obtiene todas las plantas de reciclaje
	public List<PlantaReciclaje> getPlantas() {
		return plantaRepository.values().stream()
				.sorted((p1, p2) -> Long.compare(p1.getId(), p2.getId()))
				.toList();
	}

	// Obtiene una planta de reciclaje por su ID
	public PlantaReciclaje getPlantaById(long id) {
		return plantaRepository.get(id);
	}

	// Obtiene la capacidad (en toneladas) disponible en una fecha concreta para una planta concreta
	public double getCapacidadDisponible(long plantaId, LocalDate fecha) {
		validarFechaConsulta(fecha);

		PlantaReciclaje planta = plantaRepository.get(plantaId);

		if (planta == null) {
			throw new RuntimeException("Plant not found");
		}

		return planta.getCapacidadDisponible(fecha);
	}

	// Una fecha es válida cuando no está más de 10 días en el futuro
	public static void validarFechaConsulta(LocalDate fecha) {
		if (fecha == null || fecha.isAfter(LocalDate.now().plusDays(DIAS_ANTELACION))) {
			throw new IllegalArgumentException("Invalid date");
		}
	}

	// Método para añadir una nueva planta de reciclaje
	public void addPlanta(PlantaReciclaje planta) {
		if (planta != null) {
			plantaRepository.putIfAbsent(planta.getId(), planta);
		}
	}
}
