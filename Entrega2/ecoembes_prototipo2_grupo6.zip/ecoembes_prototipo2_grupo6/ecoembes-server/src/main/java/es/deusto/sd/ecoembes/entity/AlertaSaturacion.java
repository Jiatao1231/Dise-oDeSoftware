package es.deusto.sd.ecoembes.entity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;

// Alerta de saturación enviada automáticamente por correo al personal de Ecoembes
@Entity
public class AlertaSaturacion {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private LocalDateTime fechaHora;
	private int contenedoresAltos;
	private int totalContenedores;
	private double porcentaje;

	@ElementCollection(fetch = FetchType.EAGER)
	@CollectionTable(name = "alerta_destinatarios", joinColumns = @JoinColumn(name = "alerta_id"))
	@Column(name = "email")
	private List<String> destinatarios = new ArrayList<>();

	@Column(length = 1000)
	private String mensaje;

	public AlertaSaturacion() { }

	public AlertaSaturacion(LocalDateTime fechaHora, int contenedoresAltos, int totalContenedores, double porcentaje,
			List<String> destinatarios, String mensaje) {
		this.fechaHora = fechaHora;
		this.contenedoresAltos = contenedoresAltos;
		this.totalContenedores = totalContenedores;
		this.porcentaje = porcentaje;
		this.destinatarios = new ArrayList<>(destinatarios);
		this.mensaje = mensaje;
	}

	// Getters and setters
	public Long getId() {
		return id;
	}

	public LocalDateTime getFechaHora() {
		return fechaHora;
	}

	public void setFechaHora(LocalDateTime fechaHora) {
		this.fechaHora = fechaHora;
	}

	public int getContenedoresAltos() {
		return contenedoresAltos;
	}

	public void setContenedoresAltos(int contenedoresAltos) {
		this.contenedoresAltos = contenedoresAltos;
	}

	public int getTotalContenedores() {
		return totalContenedores;
	}

	public void setTotalContenedores(int totalContenedores) {
		this.totalContenedores = totalContenedores;
	}

	public double getPorcentaje() {
		return porcentaje;
	}

	public void setPorcentaje(double porcentaje) {
		this.porcentaje = porcentaje;
	}

	public List<String> getDestinatarios() {
		return destinatarios;
	}

	public void setDestinatarios(List<String> destinatarios) {
		this.destinatarios = destinatarios;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
}
