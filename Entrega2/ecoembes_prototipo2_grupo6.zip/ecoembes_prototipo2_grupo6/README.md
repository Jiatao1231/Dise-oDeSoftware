# Ecoembes — Prototipo 2 (Grupo 6)

Tres proyectos independientes (Gradle, JDK 21). Arranca **primero las plantas** y después Ecoembes:

| Proyecto | Descripción | Puerto | Arranque |
|:--|:--|:--|:--|
| `contsocket-server` | ContSocket Ltd.: sockets TCP, datos en memoria | 9090 | `./gradlew run` |
| `plassb-server` | PlasSB Ltd.: Spring Boot + JPA + H2 (REST) | 8084 | `./gradlew bootRun` |
| `ecoembes-server` | Servidor Ecoembes: Spring Boot + JPA + H2 | 8083 | `./gradlew bootRun` |

(Windows: `.\gradlew.bat ...`.) Tests: `./gradlew test` en cada proyecto.

* Swagger Ecoembes: <http://localhost:8083/swagger-ui/index.html>
* Swagger PlasSB: <http://localhost:8084/swagger-ui/index.html>
* Diseño del API de las plantas y cambios del diagrama de clases: `documentos/API_REST_Plantas.md`

## Configuración (`ecoembes-server/src/main/resources/application.properties`)

```
ecoembes.plantas.plassb.url=http://localhost:8084
ecoembes.plantas.contsocket.host=localhost
ecoembes.plantas.contsocket.port=9090
```

## Datos de prueba (`DataInitializer`)

* Personal: `ana@ecoembes.com` / `Ana1234!`, `mikel@ecoembes.com` / `Mikel1234!`, `laura@ecoembes.com` / `Laura1234!`, `Jiati@ecoembes.com` / `Jiati1234!`
* Plantas: 1 = PlasSB Ltd. (REST, 0,60 t/día), 2 = ContSocket Ltd. (sockets, 0,40 t/día)
* Contenedores 1 a 8 con registros de los últimos 3 días.
* Las BBDD H2 son ficheros (`./data/...`): se cargan solo la primera vez. Para reiniciar los datos, borra la carpeta `data`.

## Flujo de demo en Swagger

1. `POST /auth/login` → token.
2. `GET /ecoembes/plantas/capacidad?fecha=...` → pregunta a PlasSB (REST) y ContSocket (sockets).
3. `POST /ecoembes/asignaciones` (`plantaId` 1 ó 2) → comprueba capacidad, guarda en BD y notifica a la planta.
4. Repite `GET .../capacidad`: la capacidad de esa planta ha bajado.
5. `GET /ecoembes/asignaciones` (auditoría) y `POST /auth/logout`.

## Patrones

Façade, Application Service, DTO, State Management (tokens), **DAO** (`dao`), **Service Gateway** (`external`) y **Factoría** (`PlantaGatewayFactory`).
