package es.deusto.sd.ecoembes.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Service;

import es.deusto.sd.ecoembes.entity.Contenedor;
import es.deusto.sd.ecoembes.entity.EstadoContenedor;
import es.deusto.sd.ecoembes.entity.RegistroContenedor;

@Service
public class ContenedorService {

	// Simulando el repositorio de contenedores.
	// ConcurrentHashMap se utiliza porque el repositorio se comparte entre los hilos que Spring
	// utiliza para atender peticiones HTTP concurrentes.
	private final Map<Long, Contenedor> contenedorRepository = new ConcurrentHashMap<>();

	// Obtiene todos los contenedores
	public List<Contenedor> getContenedores() {
		return contenedorRepository.values().stream()
				.sorted((c1, c2) -> Long.compare(c1.getId(), c2.getId()))
				.toList();
	}

	// Obtener un contenedor por su ID
	public Contenedor getContenedorById(long id) {
		return contenedorRepository.get(id);
	}

	// Crea un nuevo contenedor
	public Contenedor crearContenedor(long id, String ubicacion, String codigoPostal, int capacidadInicial) {
		if (ubicacion == null || ubicacion.isBlank() || codigoPostal == null || codigoPostal.isBlank()
				|| capacidadInicial <= 0) {
			throw new IllegalArgumentException("Invalid container data");
		}

		Contenedor contenedor = new Contenedor(id, ubicacion, codigoPostal, capacidadInicial);

		if (contenedorRepository.putIfAbsent(id, contenedor) != null) {
			throw new RuntimeException("Container already exists");
		}

		return contenedor;
	}

	// Registra la actualización diaria enviada por el sensor de un contenedor
	public void actualizarContenedor(long id, LocalDate fecha, int numEnvases, EstadoContenedor nivelLlenado) {
		if (numEnvases < 0 || nivelLlenado == null) {
			throw new IllegalArgumentException("Invalid container data");
		}

		// Si no hay fecha, se registra la actualización para hoy
		LocalDate fechaRegistro = (fecha != null) ? fecha : LocalDate.now();

		if (fechaRegistro.isAfter(LocalDate.now())) {
			throw new IllegalArgumentException("Invalid container data");
		}

		Contenedor contenedor = contenedorRepository.get(id);

		if (contenedor == null) {
			throw new RuntimeException("Container not found");
		}

		contenedor.addRegistro(new RegistroContenedor(fechaRegistro, numEnvases, nivelLlenado, contenedor));
	}

	// Obtiene las actualizaciones de un contenedor entre dos fechas (ambas incluidas)
	public List<RegistroContenedor> getRegistrosByFechas(long id, LocalDate fechaInicio, LocalDate fechaFin) {
		if (fechaInicio == null || fechaFin == null || fechaInicio.isAfter(fechaFin)) {
			throw new IllegalArgumentException("Invalid date range");
		}

		Contenedor contenedor = contenedorRepository.get(id);

		if (contenedor == null) {
			throw new RuntimeException("Container not found");
		}

		return contenedor.getRegistros().stream()
				.filter(r -> !r.getFecha().isBefore(fechaInicio) && !r.getFecha().isAfter(fechaFin))
				.sorted((r1, r2) -> r1.getFecha().compareTo(r2.getFecha()))
				.toList();
	}

	// Obtiene el estado de los contenedores de una zona (código postal) en una fecha concreta
	public List<RegistroContenedor> getRegistrosByZona(String codigoPostal, LocalDate fecha) {
		if (codigoPostal == null || codigoPostal.isBlank() || fecha == null) {
			throw new IllegalArgumentException("Invalid date range");
		}

		return getContenedores().stream()
				.filter(c -> codigoPostal.equals(c.getCodigoPostal()))
				.map(c -> c.getRegistro(fecha))
				.filter(r -> r.isPresent())
				.map(r -> r.get())
				.toList();
	}
	
	// Modifica los datos principales de un contenedor existente
	public Contenedor modificarContenedor(long id, String ubicacion, String codigoPostal, int capacidadInicial) {
		if (ubicacion == null || ubicacion.isBlank() || codigoPostal == null || codigoPostal.isBlank()
				|| capacidadInicial <= 0) {
			throw new IllegalArgumentException("Invalid container data");
		}

		Contenedor contenedor = contenedorRepository.get(id);

		if (contenedor == null) {
			throw new RuntimeException("Container not found");
		}

		contenedor.setUbicacion(ubicacion);
		contenedor.setCodigoPostal(codigoPostal);
		contenedor.setCapacidadInicial(capacidadInicial);

		return contenedor;
	}
	
}
