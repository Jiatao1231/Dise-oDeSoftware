package es.deusto.sd.ecoembes.entity;

import java.time.LocalDate;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

// Registro de la capacidad disponible (en toneladas) de una planta de reciclaje en una fecha concreta,
// tal y como la informó su servicio externo en la última consulta.
@Entity
public class RegistroPlantaReciclaje {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(nullable = false)
	private LocalDate fecha;

	private double capacidadDisponible;

	@ManyToOne
	@JoinColumn(name = "planta_id", nullable = false)
	private PlantaReciclaje planta;

	public RegistroPlantaReciclaje() { }

	public RegistroPlantaReciclaje(LocalDate fecha, double capacidadDisponible, PlantaReciclaje planta) {
		this.fecha = fecha;
		this.capacidadDisponible = capacidadDisponible;
		this.planta = planta;
	}

	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	public double getCapacidadDisponible() {
		return capacidadDisponible;
	}

	public void setCapacidadDisponible(double capacidadDisponible) {
		this.capacidadDisponible = capacidadDisponible;
	}

	public PlantaReciclaje getPlanta() {
		return planta;
	}

	public void setPlanta(PlantaReciclaje planta) {
		this.planta = planta;
	}

	// hashCode and equals (un registro por planta y fecha)
	@Override
	public int hashCode() {
		return Objects.hash(planta, fecha);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RegistroPlantaReciclaje other = (RegistroPlantaReciclaje) obj;
		return Objects.equals(planta, other.planta) && Objects.equals(fecha, other.fecha);
	}
}
