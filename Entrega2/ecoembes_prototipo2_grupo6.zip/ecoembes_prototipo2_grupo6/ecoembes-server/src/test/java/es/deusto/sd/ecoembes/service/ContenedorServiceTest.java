package es.deusto.sd.ecoembes.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;

import es.deusto.sd.ecoembes.dao.ContenedorRepository;
import es.deusto.sd.ecoembes.entity.EstadoContenedor;
import es.deusto.sd.ecoembes.entity.RegistroContenedor;

@DataJpaTest
class ContenedorServiceTest {

	@Autowired
	private ContenedorRepository contenedorRepository;

	private ContenedorService service;
	private final LocalDate hoy = LocalDate.now();

	@BeforeEach
	void setUp() {
		service = new ContenedorService(contenedorRepository);
		service.crearContenedor(1, "Gran Via 25, Bilbao", "48001", 2000);
		service.crearContenedor(2, "Calle Ercilla 15, Bilbao", "48009", 2000);
	}

	@Test
	void createdContainersArePersistedAndSortedById() {
		service.crearContenedor(3, "Calle Ledesma 8, Bilbao", "48011", 2000);

		assertEquals(3, contenedorRepository.count());
		assertEquals(1, service.getContenedores().get(0).getId());
		assertEquals("48011", service.getContenedorById(3).getCodigoPostal());
	}

	@Test
	void createRejectsInvalidDataAndDuplicates() {
		assertThrows(IllegalArgumentException.class, () -> service.crearContenedor(9, "", "48001", 2000));
		assertThrows(IllegalArgumentException.class, () -> service.crearContenedor(9, "Calle", "48001", 0));

		RuntimeException e = assertThrows(RuntimeException.class,
				() -> service.crearContenedor(1, "Otra calle", "48001", 2000));
		assertEquals("Container already exists", e.getMessage());
	}

	@Test
	void sensorUpdatesAreStoredAndTheLastOneIsTheMostRecent() {
		service.actualizarContenedor(1, hoy.minusDays(1), 500, EstadoContenedor.VERDE);
		service.actualizarContenedor(1, hoy, 1500, EstadoContenedor.NARANJA);

		RegistroContenedor ultimo = service.getContenedorById(1).getUltimoRegistro().get();
		assertEquals(hoy, ultimo.getFecha());
		assertEquals(1500, ultimo.getNumEnvases());
		assertEquals(EstadoContenedor.NARANJA, ultimo.getNivelLlenado());
	}

	@Test
	void thereIsOnlyOneUpdatePerDay() {
		service.actualizarContenedor(1, hoy, 500, EstadoContenedor.VERDE);
		service.actualizarContenedor(1, hoy, 1900, EstadoContenedor.ROJO);

		assertEquals(1, service.getContenedorById(1).getRegistros().size());
		assertEquals(EstadoContenedor.ROJO, service.getContenedorById(1).getRegistro(hoy).get().getNivelLlenado());
	}

	@Test
	void updateRejectsInvalidDataAndUnknownContainers() {
		assertThrows(IllegalArgumentException.class, () -> service.actualizarContenedor(1, hoy, -1, EstadoContenedor.VERDE));
		assertThrows(IllegalArgumentException.class, () -> service.actualizarContenedor(1, hoy, 10, null));
		assertThrows(IllegalArgumentException.class,
				() -> service.actualizarContenedor(1, hoy.plusDays(1), 10, EstadoContenedor.VERDE));
		assertThrows(RuntimeException.class, () -> service.actualizarContenedor(99, hoy, 10, EstadoContenedor.VERDE));
	}

	@Test
	void recordsAreFilteredByDateRange() {
		for (int dias = 4; dias >= 0; dias--) {
			service.actualizarContenedor(1, hoy.minusDays(dias), 100 * (5 - dias), EstadoContenedor.VERDE);
		}

		List<RegistroContenedor> registros = service.getRegistrosByFechas(1, hoy.minusDays(2), hoy.minusDays(1));

		assertEquals(2, registros.size());
		assertEquals(hoy.minusDays(2), registros.get(0).getFecha());
		assertTrue(service.getRegistrosByFechas(1, hoy.plusDays(1), hoy.plusDays(2)).isEmpty());
		assertThrows(IllegalArgumentException.class, () -> service.getRegistrosByFechas(1, hoy, hoy.minusDays(1)));
		assertThrows(RuntimeException.class, () -> service.getRegistrosByFechas(99, hoy, hoy));
	}

	@Test
	void containersOfAZoneAreReturnedForADate() {
		service.actualizarContenedor(1, hoy, 100, EstadoContenedor.VERDE);
		service.actualizarContenedor(2, hoy, 200, EstadoContenedor.VERDE);

		assertEquals(1, service.getRegistrosByZona("48001", hoy).size());
		assertTrue(service.getRegistrosByZona("48001", hoy.minusDays(1)).isEmpty());
		assertTrue(service.getRegistrosByZona("99999", hoy).isEmpty());
		assertThrows(IllegalArgumentException.class, () -> service.getRegistrosByZona("48001", null));
	}

	@Test
	void containerDetailsCanBeModified() {
		service.modificarContenedor(1, "Nueva calle 1, Bilbao", "48010", 3000);

		assertEquals("48010", service.getContenedorById(1).getCodigoPostal());
		assertEquals(3000, service.getContenedorById(1).getCapacidadInicial());
		assertThrows(RuntimeException.class, () -> service.modificarContenedor(99, "Calle", "48001", 10));
		assertThrows(IllegalArgumentException.class, () -> service.modificarContenedor(1, "Calle", "", 10));
	}
}
