package es.deusto.sd.ecoembes.dto;

public class SolicitudAlertaDTO {
    private double umbralPorcentaje = 80.0;
    private String observaciones;

    public SolicitudAlertaDTO() {}

    public SolicitudAlertaDTO(double umbralPorcentaje, String observaciones) {
        this.umbralPorcentaje = umbralPorcentaje;
        this.observaciones = observaciones;
    }

    public double getUmbralPorcentaje() {
        return umbralPorcentaje;
    }

    public void setUmbralPorcentaje(double umbralPorcentaje) {
        this.umbralPorcentaje = umbralPorcentaje;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }
}