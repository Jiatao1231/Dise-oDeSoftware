package es.deusto.sd.ecoembes.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class AlertaDTO {
    private long idAlerta;
    private LocalDate fecha;
    private double porcentajeSaturacion;
    private int totalContenedores;
    private int contenedoresSaturados;
    private String estado;
    private LocalDateTime timestamp;
    private int destinatariosNotificados;

    public AlertaDTO() {}

    public AlertaDTO(long idAlerta, LocalDate fecha, double porcentajeSaturacion, int totalContenedores,
                     int contenedoresSaturados, String estado, LocalDateTime timestamp, int destinatariosNotificados) {
        this.idAlerta = idAlerta;
        this.fecha = fecha;
        this.porcentajeSaturacion = porcentajeSaturacion;
        this.totalContenedores = totalContenedores;
        this.contenedoresSaturados = contenedoresSaturados;
        this.estado = estado;
        this.timestamp = timestamp;
        this.destinatariosNotificados = destinatariosNotificados;
    }

    public long getIdAlerta() { return idAlerta; }
    public void setIdAlerta(long idAlerta) { this.idAlerta = idAlerta; }

    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }

    public double getPorcentajeSaturacion() { return porcentajeSaturacion; }
    public void setPorcentajeSaturacion(double porcentajeSaturacion) { this.porcentajeSaturacion = porcentajeSaturacion; }

    public int getTotalContenedores() { return totalContenedores; }
    public void setTotalContenedores(int totalContenedores) { this.totalContenedores = totalContenedores; }

    public int getContenedoresSaturados() { return contenedoresSaturados; }
    public void setContenedoresSaturados(int contenedoresSaturados) { this.contenedoresSaturados = contenedoresSaturados; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }

    public int getDestinatariosNotificados() { return destinatariosNotificados; }
    public void setDestinatariosNotificados(int destinatariosNotificados) { this.destinatariosNotificados = destinatariosNotificados; }
}