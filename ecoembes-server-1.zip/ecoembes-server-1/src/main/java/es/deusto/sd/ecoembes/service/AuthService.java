package es.deusto.sd.ecoembes.service;

import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Service;

import es.deusto.sd.ecoembes.entity.PersonalEcoembes;

@Service
public class AuthService {

	// Simular un repositorio de personal (seguro para hilos: se comparte entre los hilos que atienden las peticiones HTTP)
	private final Map<String, PersonalEcoembes> personalRepository = new ConcurrentHashMap<>();

	// Almacena el estado de la sesión del personal que ha iniciado sesión (estado del servidor)
	private final Map<String, PersonalEcoembes> tokenStore = new ConcurrentHashMap<>();

	// Metodo de inicio de sesión que comprueba si la persona existe y valida la contraseña
	public Optional<String> login(String email, String password) {
		if (email == null || password == null) {
			return Optional.empty();
		}

		PersonalEcoembes personal = personalRepository.get(email);

		if (personal != null && personal.checkPassword(password)) {
			String token = generateToken();  // Genera un token único y no adivinable para la sesión
			tokenStore.put(token, personal); // Almacena el token en el estado del servidor para la sesión del personal

			return Optional.of(token);
		} else {
			return Optional.empty();
		}
	}

	// Metodo de cierre de sesión que elimina el token del estado del servidor
	public Optional<Boolean> logout(String token) {
		if (token != null && tokenStore.containsKey(token)) {
			tokenStore.remove(token);

			return Optional.of(true);
		} else {
			return Optional.empty();
		}
	}

	// Método para añadir un nuevo personal al repositorio
	public void addPersonal(PersonalEcoembes personal) {
		if (personal != null) {
			personalRepository.putIfAbsent(personal.getEmail(), personal);
		}
	}

	// Método para obtener la persona basada en el token
	public PersonalEcoembes getPersonalByToken(String token) {
		if (token == null) {
			return null;
		}

		return tokenStore.get(token);
	}

	// Método para obtener la persona basada en el correo electrónico
	public PersonalEcoembes getPersonalByEmail(String email) {
		return personalRepository.get(email);
	}

	// Genera un token de sesión único y no adivinable.
	private static String generateToken() {
		return UUID.randomUUID().toString();
	}
}
