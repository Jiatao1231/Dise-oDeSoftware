package es.deusto.sd.ecoembes.external;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;

// Service Gateway de ContSocket Ltd.: el servicio externo se comunica mediante sockets TCP.
//
// Protocolo (texto, una línea por mensaje, campos separados por ';'; una petición por conexión):
//   CAPACIDAD;yyyy-MM-dd                         ->  OK;<toneladas>             | ERROR;<codigo>;<mensaje>
//   ASIGNAR;yyyy-MM-dd;<contenedores>;<envases>  ->  OK;<capacidadRestante>     | ERROR;<codigo>;<mensaje>
public class ContSocketGateway implements IPlantaGateway {

	private static final String PLANT_UNAVAILABLE = "Plant service unavailable";
	private static final int CONNECT_TIMEOUT_MS = 3000;
	private static final int READ_TIMEOUT_MS = 5000;

	private final String host;
	private final int port;

	public ContSocketGateway(String host, int port) {
		this.host = host;
		this.port = port;
	}

	@Override
	public double getCapacidadDisponible(LocalDate fecha) {
		String[] respuesta = enviar("CAPACIDAD;" + fecha);

		try {
			return Double.parseDouble(respuesta[1]);
		} catch (RuntimeException e) {
			throw new RuntimeException(PLANT_UNAVAILABLE);
		}
	}

	@Override
	public void asignarContenedores(LocalDate fecha, int numContenedores, int totalEnvases) {
		enviar("ASIGNAR;" + fecha + ";" + numContenedores + ";" + totalEnvases);
	}

	// Envía un mensaje y devuelve la respuesta ya dividida en campos. Traduce las respuestas de error.
	private String[] enviar(String mensaje) {
		String linea;

		try (Socket socket = new Socket()) {
			socket.connect(new InetSocketAddress(host, port), CONNECT_TIMEOUT_MS);
			socket.setSoTimeout(READ_TIMEOUT_MS);

			PrintWriter out = new PrintWriter(socket.getOutputStream(), true, StandardCharsets.UTF_8);
			BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));

			out.println(mensaje);
			linea = in.readLine();
		} catch (IOException e) {
			throw new RuntimeException(PLANT_UNAVAILABLE);
		}

		if (linea == null) {
			throw new RuntimeException(PLANT_UNAVAILABLE);
		}

		String[] campos = linea.split(";");

		if ("OK".equals(campos[0]) && campos.length >= 2) {
			return campos;
		}

		if ("ERROR".equals(campos[0]) && campos.length >= 2) {
			switch (campos[1]) {
				case "400":
					throw new IllegalArgumentException("Invalid request");
				case "409":
					throw new RuntimeException("Insufficient plant capacity");
				default:
					throw new RuntimeException(PLANT_UNAVAILABLE);
			}
		}

		throw new RuntimeException(PLANT_UNAVAILABLE);
	}
}
