package es.deusto.sd.ecoembes.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public final class Asignacion {

	// Inicialización de la constante para el peso medio de un envase en toneladas (50 gramos)
	public static final double PESO_MEDIO_ENVASE_TONELADAS = 0.00005;

	private long id;
	private LocalDate fecha;
	private int totalEnvases;
	private LocalDateTime fechaRegistro;
	private PlantaReciclaje planta;
	private PersonalEcoembes personal;
	private List<Contenedor> contenedores = new ArrayList<>();

	public Asignacion() { }

	public Asignacion(long id, LocalDate fecha, int totalEnvases, LocalDateTime fechaRegistro) {
		this.id = id;
		this.fecha = fecha;
		this.totalEnvases = totalEnvases;
		this.fechaRegistro = fechaRegistro;
	}

	public Asignacion(long id, LocalDate fecha, int totalEnvases, PlantaReciclaje planta,
			          PersonalEcoembes personal, List<Contenedor> contenedores) {
		this.id = id;
		this.fecha = fecha;
		this.totalEnvases = totalEnvases;
		this.fechaRegistro = LocalDateTime.now();
		this.planta = planta;
		this.personal = personal;
		this.contenedores = contenedores;

		if (this.planta != null) {
			this.planta.getAsignaciones().add(this);
		}

		if (this.personal != null) {
			synchronized (this.personal) {
				this.personal.getAsignaciones().add(this);
			}
		}
	}
	
	// Getters and setters
	public double getToneladas() {
		return totalEnvases * PESO_MEDIO_ENVASE_TONELADAS;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	public int getTotalEnvases() {
		return totalEnvases;
	}

	public void setTotalEnvases(int totalEnvases) {
		this.totalEnvases = totalEnvases;
	}

	public LocalDateTime getFechaRegistro() {
		return fechaRegistro;
	}

	public void setFechaRegistro(LocalDateTime fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

	public PlantaReciclaje getPlanta() {
		return planta;
	}

	public void setPlanta(PlantaReciclaje planta) {
		this.planta = planta;
	}

	public PersonalEcoembes getPersonal() {
		return personal;
	}

	public void setPersonal(PersonalEcoembes personal) {
		this.personal = personal;
	}

	public List<Contenedor> getContenedores() {
		return contenedores;
	}

	public void setContenedores(List<Contenedor> contenedores) {
		this.contenedores = contenedores;
	}

	// hashCode and equals
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Asignacion other = (Asignacion) obj;
		return id == other.id;
	}
}
