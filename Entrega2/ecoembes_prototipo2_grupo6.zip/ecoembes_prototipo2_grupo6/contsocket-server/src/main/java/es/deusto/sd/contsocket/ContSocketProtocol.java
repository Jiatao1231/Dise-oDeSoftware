package es.deusto.sd.contsocket;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Locale;
import java.util.NoSuchElementException;

// Protocolo de texto de ContSocket Ltd. (una línea por mensaje, campos separados por ';').
//
//   CAPACIDAD;yyyy-MM-dd                         ->  OK;<toneladas disponibles>
//   ASIGNAR;yyyy-MM-dd;<contenedores>;<envases>  ->  OK;<toneladas que quedan ese día>
//
// Respuestas de error: ERROR;<codigo>;<mensaje>   (400 petición inválida, 404 sin capacidad, 409 sin capacidad suficiente,
// 500 error interno). Los códigos reproducen los de HTTP para que sean fáciles de recordar.
public class ContSocketProtocol {

	private final CapacidadStore store;

	public ContSocketProtocol(CapacidadStore store) {
		this.store = store;
	}

	// Procesa una línea recibida del cliente y devuelve la línea de respuesta
	public String procesar(String linea) {
		try {
			if (linea == null || linea.isBlank()) {
				return error(400, "Empty request");
			}

			String[] campos = linea.trim().split(";");

			switch (campos[0]) {
				case "CAPACIDAD":
					if (campos.length != 2) {
						return error(400, "Invalid request");
					}

					return ok(store.getCapacidadDisponible(LocalDate.parse(campos[1])));
				case "ASIGNAR":
					if (campos.length != 4) {
						return error(400, "Invalid request");
					}

					return ok(store.asignar(LocalDate.parse(campos[1]), Integer.parseInt(campos[2]),
							Integer.parseInt(campos[3])));
				default:
					return error(400, "Unknown command");
			}
		} catch (DateTimeParseException | IllegalArgumentException e) {
			return error(400, "Invalid request");
		} catch (NoSuchElementException e) {
			return error(404, e.getMessage());
		} catch (IllegalStateException e) {
			return error(409, e.getMessage());
		} catch (RuntimeException e) {
			return error(500, "Internal error");
		}
	}

	private static String ok(double valor) {
		return String.format(Locale.ROOT, "OK;%s", valor);
	}

	private static String error(int codigo, String mensaje) {
		return "ERROR;" + codigo + ";" + mensaje;
	}
}
