package es.deusto.sd.plassb.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;

import es.deusto.sd.plassb.dao.AsignacionPlantaRepository;
import es.deusto.sd.plassb.dao.CapacidadDiariaRepository;
import es.deusto.sd.plassb.entity.CapacidadDiaria;

@DataJpaTest
class PlasSBServiceTest {

	@Autowired private CapacidadDiariaRepository capacidadRepository;
	@Autowired private AsignacionPlantaRepository asignacionRepository;

	private PlasSBService service;
	private final LocalDate hoy = LocalDate.now();

	@BeforeEach
	void setUp() {
		service = new PlasSBService(capacidadRepository, asignacionRepository);
		// 0.1 t/día = 2000 envases de 50 gramos
		capacidadRepository.saveAndFlush(new CapacidadDiaria(hoy, 0.1));
		capacidadRepository.saveAndFlush(new CapacidadDiaria(hoy.plusDays(1), 0.1));
	}

	@Test
	void capacityWithoutAssignmentsIsTheDeclaredCapacity() {
		assertEquals(0.1, service.getCapacidadDisponible(hoy), 0.000001);
	}

	@Test
	void assignmentReducesTheCapacityOfThatDayOnly() {
		service.asignarContenedores(hoy, 2, 1000);

		assertEquals(0.05, service.getCapacidadDisponible(hoy), 0.000001);
		assertEquals(0.1, service.getCapacidadDisponible(hoy.plusDays(1)), 0.000001);
		assertEquals(1, asignacionRepository.count());
	}

	@Test
	void assignmentIsRejectedWhenItExceedsTheCapacity() {
		RuntimeException e = assertThrows(RuntimeException.class, () -> service.asignarContenedores(hoy, 3, 2300));

		assertEquals("Insufficient capacity", e.getMessage());
		assertEquals(0, asignacionRepository.count());
	}

	@Test
	void theExactCapacityCanBeAssigned() {
		service.asignarContenedores(hoy, 4, 2000);

		assertEquals(0.0, service.getCapacidadDisponible(hoy), 0.000001);
	}

	@Test
	void invalidRequestsAreRejected() {
		assertThrows(IllegalArgumentException.class, () -> service.getCapacidadDisponible(null));
		assertThrows(IllegalArgumentException.class, () -> service.getCapacidadDisponible(hoy.plusDays(11)));
		assertThrows(IllegalArgumentException.class, () -> service.asignarContenedores(hoy, 0, 100));
		assertThrows(IllegalArgumentException.class, () -> service.asignarContenedores(hoy, 1, 0));
		// Sin capacidad declarada para esa fecha
		assertThrows(RuntimeException.class, () -> service.getCapacidadDisponible(hoy.plusDays(5)));
	}
}
