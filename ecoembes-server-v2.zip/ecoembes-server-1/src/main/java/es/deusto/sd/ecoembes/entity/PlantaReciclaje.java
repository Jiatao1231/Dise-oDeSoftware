package es.deusto.sd.ecoembes.entity;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;

public class PlantaReciclaje {
	private long id;
	private String nombre;
	private double capacidadDiaria;
	// Lista segura de hilos: se comparte entre los hilos que atienden las peticiones HTTP
	private List<Asignacion> asignaciones = new CopyOnWriteArrayList<>();
	// Registros de la capacidad de la planta por fecha (composición con RegistroPlantaReciclaje)
	private List<RegistroPlantaReciclaje> registros = new CopyOnWriteArrayList<>();

	public PlantaReciclaje() { }

	public PlantaReciclaje(long id, String nombre, double capacidadDiaria) {
		this.id = id;
		this.nombre = nombre;
		this.capacidadDiaria = capacidadDiaria;
	}

	// synchronized: además de calcular la capacidad, deja guardado el registro de esa fecha
	public synchronized double getCapacidadDisponible(LocalDate fecha) {
		double asignado = asignaciones.stream()
				.filter(a -> a.getFecha().equals(fecha))
				.mapToDouble(Asignacion::getToneladas)
				.sum();

		// Redondea a 6 decimales y asegura que no sea negativo
		double disponible = Math.round(Math.max(0.0, capacidadDiaria - asignado) * 1_000_000d) / 1_000_000d;

		// Solo se mantiene un registro por fecha: si ya había uno, se reemplaza
		registros.removeIf(r -> r.getFecha().equals(fecha));
		registros.add(new RegistroPlantaReciclaje(fecha, capacidadDiaria, disponible));

		return disponible;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getCapacidadDiaria() {
		return capacidadDiaria;
	}

	public void setCapacidadDiaria(double capacidadDiaria) {
		this.capacidadDiaria = capacidadDiaria;
	}

	public List<Asignacion> getAsignaciones() {
		return asignaciones;
	}

	public void setAsignaciones(List<Asignacion> asignaciones) {
		this.asignaciones = asignaciones;
	}

	public List<RegistroPlantaReciclaje> getRegistros() {
		return registros;
	}

	public void setRegistros(List<RegistroPlantaReciclaje> registros) {
		this.registros = registros;
	}

	// hashCode and equals
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PlantaReciclaje other = (PlantaReciclaje) obj;
		return id == other.id;
	}
}
