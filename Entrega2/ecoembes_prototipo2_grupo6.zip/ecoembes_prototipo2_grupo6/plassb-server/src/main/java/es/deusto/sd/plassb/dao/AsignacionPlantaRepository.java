package es.deusto.sd.plassb.dao;

import java.time.LocalDate;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import es.deusto.sd.plassb.entity.AsignacionPlanta;

public interface AsignacionPlantaRepository extends JpaRepository<AsignacionPlanta, Long> {

	// Toneladas ya asignadas para una fecha (0 si no hay ninguna)
	@Query("select coalesce(sum(a.toneladas), 0.0) from AsignacionPlanta a where a.fecha = :fecha")
	double sumToneladasByFecha(@Param("fecha") LocalDate fecha);
}
