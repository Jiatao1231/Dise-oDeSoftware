package es.deusto.sd.ecoembes.external;

import java.time.LocalDate;

// Service Gateway: interfaz común de los servicios externos de las plantas de reciclaje.
// Los servicios de aplicación (PlantaService, AsignacionService) solo conocen esta interfaz y
// son agnósticos de la tecnología concreta (REST, sockets...) de cada planta.
public interface IPlantaGateway {

	// Capacidad disponible (en toneladas) de la planta en una fecha.
	// Lanza IllegalArgumentException si la fecha no es válida y RuntimeException("Plant service unavailable")
	// si no se puede contactar con el servicio externo.
	double getCapacidadDisponible(LocalDate fecha);

	// Notifica a la planta una asignación: número de contenedores y número estimado de envases.
	// Lanza RuntimeException("Insufficient plant capacity") si la planta rechaza la asignación por falta de capacidad.
	void asignarContenedores(LocalDate fecha, int numContenedores, int totalEnvases);
}
