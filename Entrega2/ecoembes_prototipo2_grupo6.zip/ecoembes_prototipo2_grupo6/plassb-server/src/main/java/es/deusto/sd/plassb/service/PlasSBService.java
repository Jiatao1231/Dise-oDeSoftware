package es.deusto.sd.plassb.service;

import java.time.LocalDate;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import es.deusto.sd.plassb.dao.AsignacionPlantaRepository;
import es.deusto.sd.plassb.dao.CapacidadDiariaRepository;
import es.deusto.sd.plassb.entity.AsignacionPlanta;
import es.deusto.sd.plassb.entity.CapacidadDiaria;

@Service
public class PlasSBService {

	private static final Logger logger = LoggerFactory.getLogger(PlasSBService.class);

	// La capacidad de la planta solo está disponible con 10 días de antelación
	public static final int DIAS_ANTELACION = 10;

	private final CapacidadDiariaRepository capacidadRepository;
	private final AsignacionPlantaRepository asignacionRepository;

	public PlasSBService(CapacidadDiariaRepository capacidadRepository, AsignacionPlantaRepository asignacionRepository) {
		this.capacidadRepository = capacidadRepository;
		this.asignacionRepository = asignacionRepository;
	}

	// Capacidad disponible (toneladas) en una fecha: capacidad declarada menos lo ya asignado
	public double getCapacidadDisponible(LocalDate fecha) {
		validarFecha(fecha);

		Optional<CapacidadDiaria> capacidad = capacidadRepository.findByFecha(fecha);

		if (capacidad.isEmpty()) {
			throw new RuntimeException("Capacity not found");
		}

		return disponible(capacidad.get());
	}

	// Registra una asignación recibida desde Ecoembes. Se rechaza si supera la capacidad disponible del día.
	@Transactional
	public AsignacionPlanta asignarContenedores(LocalDate fecha, int numContenedores, int totalEnvases) {
		if (numContenedores <= 0 || totalEnvases <= 0) {
			throw new IllegalArgumentException("Invalid assignment data");
		}

		validarFecha(fecha);

		// Se bloquea la fila de la capacidad del día para que dos asignaciones concurrentes no la superen
		Optional<CapacidadDiaria> capacidad = capacidadRepository.findByFechaForUpdate(fecha);

		if (capacidad.isEmpty()) {
			throw new RuntimeException("Capacity not found");
		}

		AsignacionPlanta asignacion = new AsignacionPlanta(fecha, numContenedores, totalEnvases);

		if (redondear(asignacion.getToneladas()) > disponible(capacidad.get())) {
			throw new RuntimeException("Insufficient capacity");
		}

		AsignacionPlanta guardada = asignacionRepository.save(asignacion);
		logger.info("Assignment received: {} containers, {} packagings ({} t) for {}", numContenedores, totalEnvases,
				guardada.getToneladas(), fecha);

		return guardada;
	}

	// Capacidad restante de un día (redondeada a 6 decimales, nunca negativa)
	private double disponible(CapacidadDiaria capacidad) {
		double asignado = asignacionRepository.sumToneladasByFecha(capacidad.getFecha());

		return redondear(Math.max(0.0, capacidad.getToneladas() - asignado));
	}

	private static double redondear(double toneladas) {
		return Math.round(toneladas * 1_000_000d) / 1_000_000d;
	}

	// Una fecha es válida cuando no está más de 10 días en el futuro
	private void validarFecha(LocalDate fecha) {
		if (fecha == null || fecha.isAfter(LocalDate.now().plusDays(DIAS_ANTELACION))) {
			throw new IllegalArgumentException("Invalid date");
		}
	}
}
