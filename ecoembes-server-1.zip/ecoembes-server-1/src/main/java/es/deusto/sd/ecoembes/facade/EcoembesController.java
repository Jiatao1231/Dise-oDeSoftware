package es.deusto.sd.ecoembes.facade;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import es.deusto.sd.ecoembes.dto.ActualizacionContenedorDTO;
import es.deusto.sd.ecoembes.dto.AsignacionDTO;
import es.deusto.sd.ecoembes.dto.CapacidadPlantaDTO;
import es.deusto.sd.ecoembes.dto.ContenedorDTO;
import es.deusto.sd.ecoembes.dto.NuevaAsignacionDTO;
import es.deusto.sd.ecoembes.dto.NuevoContenedorDTO;
import es.deusto.sd.ecoembes.dto.PlantaReciclajeDTO;
import es.deusto.sd.ecoembes.dto.RegistroContenedorDTO;
import es.deusto.sd.ecoembes.entity.Asignacion;
import es.deusto.sd.ecoembes.entity.Contenedor;
import es.deusto.sd.ecoembes.entity.EstadoContenedor;
import es.deusto.sd.ecoembes.entity.PersonalEcoembes;
import es.deusto.sd.ecoembes.entity.PlantaReciclaje;
import es.deusto.sd.ecoembes.entity.RegistroContenedor;
import es.deusto.sd.ecoembes.service.AsignacionService;
import es.deusto.sd.ecoembes.service.AuthService;
import es.deusto.sd.ecoembes.service.ContenedorService;
import es.deusto.sd.ecoembes.service.PlantaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/ecoembes")
@Tag(name = "Ecoembes Controller", description = "Operations related to containers, recycling plants and assignments")
public class EcoembesController {

	private final ContenedorService contenedorService;
	private final PlantaService plantaService;
	private final AsignacionService asignacionService;
	private final AuthService authService;

	public EcoembesController(ContenedorService contenedorService, PlantaService plantaService,
			AsignacionService asignacionService, AuthService authService) {
		this.contenedorService = contenedorService;
		this.plantaService = plantaService;
		this.asignacionService = asignacionService;
		this.authService = authService;
	}

	// GET todos los contenedores (descarga de la información actualizada de los contenedores)
	@Operation(
		summary = "Get all containers",
		description = "Returns the information of all the containers: location, number of packagings and fill level",
		responses = {
			@ApiResponse(responseCode = "200", description = "OK: List of containers retrieved successfully"),
			@ApiResponse(responseCode = "204", description = "No Content: No containers found"),
			@ApiResponse(responseCode = "401", description = "Unauthorized: User not authenticated"),
			@ApiResponse(responseCode = "500", description = "Internal server error")
		}
	)
	@GetMapping("/contenedores")
	public ResponseEntity<List<ContenedorDTO>> getAllContenedores(
			@Parameter(name = "token", description = "Authorization token", required = true)
			@RequestParam("token") String token) {
		try {
			if (authService.getPersonalByToken(token) == null) {
				return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
			}

			List<Contenedor> contenedores = contenedorService.getContenedores();

			if (contenedores.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}

			List<ContenedorDTO> dtos = new ArrayList<>();
			contenedores.forEach(contenedor -> dtos.add(contenedorToDTO(contenedor)));

			return new ResponseEntity<>(dtos, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// POST crear un nuevo contenedor
	@Operation(
		summary = "Create a new container",
		description = "Adds a new container to the system providing its identifier, location, postal code and initial capacity",
		responses = {
			@ApiResponse(responseCode = "201", description = "Created: Container created successfully"),
			@ApiResponse(responseCode = "400", description = "Bad Request: Invalid container data"),
			@ApiResponse(responseCode = "401", description = "Unauthorized: User not authenticated"),
			@ApiResponse(responseCode = "409", description = "Conflict: A container with that identifier already exists"),
			@ApiResponse(responseCode = "500", description = "Internal server error")
		}
	)
	@PostMapping("/contenedores")
	public ResponseEntity<ContenedorDTO> crearContenedor(
			@Parameter(name = "token", description = "Authorization token", required = true)
			@RequestParam("token") String token,
			@io.swagger.v3.oas.annotations.parameters.RequestBody(description = "Data of the new container", required = true)
			@RequestBody NuevoContenedorDTO nuevoContenedor) {
		try {
			if (authService.getPersonalByToken(token) == null) {
				return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
			}

			Contenedor contenedor = contenedorService.crearContenedor(nuevoContenedor.getId(),
					nuevoContenedor.getUbicacion(), nuevoContenedor.getCodigoPostal(),
					nuevoContenedor.getCapacidadInicial());

			return new ResponseEntity<>(contenedorToDTO(contenedor), HttpStatus.CREATED);
		} catch (Exception e) {
			return errorResponse(e);
		}
	}

	// POST actualizar la información de un contenedor (simula la actualización diaria del sensor)
	@Operation(
		summary = "Update the information of a container",
		description = "Simulates the daily update sent by the sensor of a container: number of packagings and fill level (VERDE, NARANJA or ROJO). If no date is provided, today is used.",
		responses = {
			@ApiResponse(responseCode = "204", description = "No Content: Container updated successfully"),
			@ApiResponse(responseCode = "400", description = "Bad Request: Invalid update data"),
			@ApiResponse(responseCode = "404", description = "Not Found: Container not found"),
			@ApiResponse(responseCode = "500", description = "Internal server error")
		}
	)
	@PostMapping("/contenedores/{contenedorId}/registros")
	public ResponseEntity<Void> actualizarContenedor(
			@Parameter(name = "contenedorId", description = "Id of the container", required = true, example = "1")
			@PathVariable("contenedorId") long id,
			@io.swagger.v3.oas.annotations.parameters.RequestBody(description = "Update sent by the sensor", required = true)
			@RequestBody ActualizacionContenedorDTO actualizacion) {
		try {
			EstadoContenedor nivelLlenado = stringToEstado(actualizacion.getNivelLlenado());

			contenedorService.actualizarContenedor(id, actualizacion.getFecha(), actualizacion.getNumEnvases(),
					nivelLlenado);

			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} catch (Exception e) {
			return errorResponse(e);
		}
	}

	// GET el estado del contenedor entre dos fechas
	@Operation(
		summary = "Get the usage/state of a container between two dates",
		description = "Returns the daily updates of a container between a start date and an end date (both included)",
		responses = {
			@ApiResponse(responseCode = "200", description = "OK: List of updates retrieved successfully"),
			@ApiResponse(responseCode = "204", description = "No Content: No updates in that period"),
			@ApiResponse(responseCode = "400", description = "Bad Request: Invalid date range"),
			@ApiResponse(responseCode = "401", description = "Unauthorized: User not authenticated"),
			@ApiResponse(responseCode = "404", description = "Not Found: Container not found"),
			@ApiResponse(responseCode = "500", description = "Internal server error")
		}
	)
	@GetMapping("/contenedores/{contenedorId}/registros")
	public ResponseEntity<List<RegistroContenedorDTO>> getRegistrosContenedor(
			@Parameter(name = "contenedorId", description = "Id of the container", required = true, example = "1")
			@PathVariable("contenedorId") long id,
			@Parameter(name = "fechaInicio", description = "Start date (yyyy-MM-dd)", required = true, example = "2026-11-01")
			@RequestParam("fechaInicio") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaInicio,
			@Parameter(name = "fechaFin", description = "End date (yyyy-MM-dd)", required = true, example = "2026-11-07")
			@RequestParam("fechaFin") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaFin,
			@Parameter(name = "token", description = "Authorization token", required = true)
			@RequestParam("token") String token) {
		try {
			if (authService.getPersonalByToken(token) == null) {
				return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
			}

			List<RegistroContenedor> registros = contenedorService.getRegistrosByFechas(id, fechaInicio, fechaFin);

			if (registros.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}

			List<RegistroContenedorDTO> dtos = new ArrayList<>();
			registros.forEach(registro -> dtos.add(registroToDTO(registro)));

			return new ResponseEntity<>(dtos, HttpStatus.OK);
		} catch (Exception e) {
			return errorResponse(e);
		}
	}

	//GET el estado de los contenedores de una zona en una fecha concreta
	@Operation(
		summary = "Get the state of the containers of a zone",
		description = "Returns the state of the containers of a zone (identified by postal code) on a given date",
		responses = {
			@ApiResponse(responseCode = "200", description = "OK: List of containers retrieved successfully"),
			@ApiResponse(responseCode = "204", description = "No Content: No containers in that zone on that date"),
			@ApiResponse(responseCode = "400", description = "Bad Request: Invalid date"),
			@ApiResponse(responseCode = "401", description = "Unauthorized: User not authenticated"),
			@ApiResponse(responseCode = "500", description = "Internal server error")
		}
	)
	@GetMapping("/zonas/{codigoPostal}/contenedores")
	public ResponseEntity<List<RegistroContenedorDTO>> getContenedoresByZona(
			@Parameter(name = "codigoPostal", description = "Postal code of the zone", required = true, example = "48001")
			@PathVariable("codigoPostal") String codigoPostal,
			@Parameter(name = "fecha", description = "Date (yyyy-MM-dd)", required = true, example = "2026-11-07")
			@RequestParam("fecha") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha,
			@Parameter(name = "token", description = "Authorization token", required = true)
			@RequestParam("token") String token) {
		try {
			if (authService.getPersonalByToken(token) == null) {
				return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
			}

			List<RegistroContenedor> registros = contenedorService.getRegistrosByZona(codigoPostal, fecha);

			if (registros.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}

			List<RegistroContenedorDTO> dtos = new ArrayList<>();
			registros.forEach(registro -> dtos.add(registroToDTO(registro)));

			return new ResponseEntity<>(dtos, HttpStatus.OK);
		} catch (Exception e) {
			return errorResponse(e);
		}
	}

	// GET todas las plantas de reciclaje
	@Operation(
		summary = "Get all recycling plants",
		description = "Returns the list of recycling plants participating in the system",
		responses = {
			@ApiResponse(responseCode = "200", description = "OK: List of plants retrieved successfully"),
			@ApiResponse(responseCode = "204", description = "No Content: No plants found"),
			@ApiResponse(responseCode = "401", description = "Unauthorized: User not authenticated"),
			@ApiResponse(responseCode = "500", description = "Internal server error")
		}
	)
	@GetMapping("/plantas")
	public ResponseEntity<List<PlantaReciclajeDTO>> getAllPlantas(
			@Parameter(name = "token", description = "Authorization token", required = true)
			@RequestParam("token") String token) {
		try {
			if (authService.getPersonalByToken(token) == null) {
				return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
			}

			List<PlantaReciclaje> plantas = plantaService.getPlantas();

			if (plantas.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}

			List<PlantaReciclajeDTO> dtos = new ArrayList<>();
			plantas.forEach(planta -> dtos.add(plantaToDTO(planta)));

			return new ResponseEntity<>(dtos, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// GET la capacidad de todas las plantas de reciclaje en una fecha concreta
	@Operation(
		summary = "Get the capacity of the recycling plants",
		description = "Returns the available capacity (in tons) of every recycling plant on a given date. The information is available up to 10 days in advance.",
		responses = {
			@ApiResponse(responseCode = "200", description = "OK: Capacities retrieved successfully"),
			@ApiResponse(responseCode = "204", description = "No Content: No plants found"),
			@ApiResponse(responseCode = "400", description = "Bad Request: Invalid date"),
			@ApiResponse(responseCode = "401", description = "Unauthorized: User not authenticated"),
			@ApiResponse(responseCode = "500", description = "Internal server error")
		}
	)
	@GetMapping("/plantas/capacidad")
	public ResponseEntity<List<CapacidadPlantaDTO>> getCapacidadPlantas(
			@Parameter(name = "fecha", description = "Date (yyyy-MM-dd)", required = true, example = "2026-11-07")
			@RequestParam("fecha") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha,
			@Parameter(name = "token", description = "Authorization token", required = true)
			@RequestParam("token") String token) {
		try {
			if (authService.getPersonalByToken(token) == null) {
				return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
			}

			List<PlantaReciclaje> plantas = plantaService.getPlantas();

			if (plantas.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}

			List<CapacidadPlantaDTO> dtos = new ArrayList<>();

			for (PlantaReciclaje planta : plantas) {
				double capacidad = plantaService.getCapacidadDisponible(planta.getId(), fecha);
				dtos.add(new CapacidadPlantaDTO(planta.getId(), planta.getNombre(), fecha, capacidad));
			}

			return new ResponseEntity<>(dtos, HttpStatus.OK);
		} catch (Exception e) {
			return errorResponse(e);
		}
	}

	// GET la capacidad de una planta de reciclaje concreta en una fecha concreta
	@Operation(
		summary = "Get the capacity of a recycling plant",
		description = "Returns the available capacity (in tons) of a recycling plant on a given date. The information is available up to 10 days in advance.",
		responses = {
			@ApiResponse(responseCode = "200", description = "OK: Capacity retrieved successfully"),
			@ApiResponse(responseCode = "400", description = "Bad Request: Invalid date"),
			@ApiResponse(responseCode = "401", description = "Unauthorized: User not authenticated"),
			@ApiResponse(responseCode = "404", description = "Not Found: Plant not found"),
			@ApiResponse(responseCode = "500", description = "Internal server error")
		}
	)
	@GetMapping("/plantas/{plantaId}/capacidad")
	public ResponseEntity<CapacidadPlantaDTO> getCapacidadPlanta(
			@Parameter(name = "plantaId", description = "Id of the recycling plant", required = true, example = "1")
			@PathVariable("plantaId") long plantaId,
			@Parameter(name = "fecha", description = "Date (yyyy-MM-dd)", required = true, example = "2026-11-07")
			@RequestParam("fecha") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha,
			@Parameter(name = "token", description = "Authorization token", required = true)
			@RequestParam("token") String token) {
		try {
			if (authService.getPersonalByToken(token) == null) {
				return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
			}

			double capacidad = plantaService.getCapacidadDisponible(plantaId, fecha);
			PlantaReciclaje planta = plantaService.getPlantaById(plantaId);

			return new ResponseEntity<>(new CapacidadPlantaDTO(plantaId, planta.getNombre(), fecha, capacidad),
					HttpStatus.OK);
		} catch (Exception e) {
			return errorResponse(e);
		}
	}

	// POST para asignar contenedores a una planta de reciclaje
	@Operation(
		summary = "Assign containers to a recycling plant",
		description = "Assigns one or more containers to a recycling plant for a given date, checking the available capacity of the plant. The person who makes the assignment is registered for audit purposes.",
		responses = {
			@ApiResponse(responseCode = "201", description = "Created: Assignment registered successfully"),
			@ApiResponse(responseCode = "400", description = "Bad Request: Invalid assignment data"),
			@ApiResponse(responseCode = "401", description = "Unauthorized: User not authenticated"),
			@ApiResponse(responseCode = "404", description = "Not Found: Plant or container not found"),
			@ApiResponse(responseCode = "409", description = "Conflict: Insufficient plant capacity or container already assigned"),
			@ApiResponse(responseCode = "500", description = "Internal server error")
		}
	)
	@PostMapping("/asignaciones")
	public ResponseEntity<AsignacionDTO> asignarContenedores(
			@Parameter(name = "token", description = "Authorization token", required = true)
			@RequestParam("token") String token,
			@io.swagger.v3.oas.annotations.parameters.RequestBody(description = "Plant, date and containers to assign", required = true)
			@RequestBody NuevaAsignacionDTO nuevaAsignacion) {
		try {
			PersonalEcoembes personal = authService.getPersonalByToken(token);

			if (personal == null) {
				return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
			}

			Asignacion asignacion = asignacionService.asignarContenedores(personal, nuevaAsignacion.getPlantaId(),
					nuevaAsignacion.getFecha(), nuevaAsignacion.getContenedores());

			return new ResponseEntity<>(asignacionToDTO(asignacion), HttpStatus.CREATED);
		} catch (Exception e) {
			return errorResponse(e);
		}
	}

	// GET todas las asignaciones
	@Operation(
		summary = "Get all the assignments",
		description = "Returns all the assignments of containers to recycling plants, including the person who made each one (audit)",
		responses = {
			@ApiResponse(responseCode = "200", description = "OK: List of assignments retrieved successfully"),
			@ApiResponse(responseCode = "204", description = "No Content: No assignments found"),
			@ApiResponse(responseCode = "401", description = "Unauthorized: User not authenticated"),
			@ApiResponse(responseCode = "500", description = "Internal server error")
		}
	)
	@GetMapping("/asignaciones")
	public ResponseEntity<List<AsignacionDTO>> getAllAsignaciones(
			@Parameter(name = "token", description = "Authorization token", required = true)
			@RequestParam("token") String token) {
		try {
			if (authService.getPersonalByToken(token) == null) {
				return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
			}

			List<Asignacion> asignaciones = asignacionService.getAsignaciones();

			if (asignaciones.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}

			List<AsignacionDTO> dtos = new ArrayList<>();
			asignaciones.forEach(asignacion -> dtos.add(asignacionToDTO(asignacion)));

			return new ResponseEntity<>(dtos, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// Traduce las excepciones lanzadas por los servicios en códigos de estado HTTP.
	private <T> ResponseEntity<T> errorResponse(Exception e) {
		if (e instanceof IllegalArgumentException) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

		String message = (e.getMessage() != null) ? e.getMessage() : "";

		switch (message) {
			case "Container not found":
			case "Plant not found":
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			case "Container without fill information":
				return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			case "Container already exists":
			case "Container already assigned":
			case "Insufficient plant capacity":
				return new ResponseEntity<>(HttpStatus.CONFLICT);
			default:
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// Convierte un String en un EstadoContenedor (valores inválidos resultan en un 400 Bad Request)
	private EstadoContenedor stringToEstado(String nivelLlenado) {
		if (nivelLlenado == null) {
			throw new IllegalArgumentException("Invalid container data");
		}

		return EstadoContenedor.valueOf(nivelLlenado.trim().toUpperCase());
	}

	// Convierte un Contenedor a un ContenedorDTO (incluyendo la última actualización del sensor)
	private ContenedorDTO contenedorToDTO(Contenedor contenedor) {
		ContenedorDTO dto = new ContenedorDTO();
		dto.setId(contenedor.getId());
		dto.setUbicacion(contenedor.getUbicacion());
		dto.setCodigoPostal(contenedor.getCodigoPostal());
		dto.setCapacidadInicial(contenedor.getCapacidadInicial());

		contenedor.getUltimoRegistro().ifPresent(registro -> {
			dto.setFechaUltimaActualizacion(registro.getFecha());
			dto.setNumEnvases(registro.getNumEnvases());
			dto.setNivelLlenado(registro.getNivelLlenado().name());
		});

		return dto;
	}

	// Convierte un RegistroContenedor a un RegistroContenedorDTO
	private RegistroContenedorDTO registroToDTO(RegistroContenedor registro) {
		return new RegistroContenedorDTO(registro.getContenedor().getId(),
				registro.getContenedor().getUbicacion(),
				registro.getContenedor().getCodigoPostal(),
				registro.getFecha(),
				registro.getNumEnvases(),
				registro.getNivelLlenado().name());
	}
	
	// Convierte una PlantaReciclaje a un PlantaReciclajeDTO
	private PlantaReciclajeDTO plantaToDTO(PlantaReciclaje planta) {
		return new PlantaReciclajeDTO(planta.getId(), planta.getNombre(), planta.getCapacidadDiaria());
	}

	// Convierte una Asignacion a un AsignacionDTO
	private AsignacionDTO asignacionToDTO(Asignacion asignacion) {
		return new AsignacionDTO(asignacion.getId(),
				asignacion.getFecha(),
				asignacion.getPlanta().getId(),
				asignacion.getPlanta().getNombre(),
				asignacion.getContenedores().size(),
				asignacion.getTotalEnvases(),
				asignacion.getToneladas(),
				asignacion.getPersonal().getEmail(),
				asignacion.getFechaRegistro());
	}
}
