package es.deusto.sd.ecoembes.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import es.deusto.sd.ecoembes.entity.EstadoContenedor;
import es.deusto.sd.ecoembes.entity.RegistroContenedor;

class ContenedorServiceTest {

	private ContenedorService contenedorService;
	private final LocalDate hoy = LocalDate.now();

	@BeforeEach
	void setUp() {
		contenedorService = new ContenedorService();
		contenedorService.crearContenedor(1, "Gran Via 25, Bilbao", "48001", 2000);
		contenedorService.crearContenedor(2, "Calle Ercilla 15, Bilbao", "48009", 2000);
	}

	@Test
	void createContainerRejectsDuplicatesAndInvalidData() {
		assertThrows(RuntimeException.class, () -> contenedorService.crearContenedor(1, "Otra calle", "48001", 100));
		assertThrows(IllegalArgumentException.class, () -> contenedorService.crearContenedor(3, "", "48001", 100));
		assertThrows(IllegalArgumentException.class, () -> contenedorService.crearContenedor(3, "Calle", "48001", 0));
		assertEquals(2, contenedorService.getContenedores().size());
	}

	@Test
	void updateReplacesTheUpdateOfTheSameDay() {
		contenedorService.actualizarContenedor(1, hoy, 500, EstadoContenedor.VERDE);
		contenedorService.actualizarContenedor(1, hoy, 1800, EstadoContenedor.ROJO);

		assertEquals(1, contenedorService.getContenedorById(1).getRegistros().size());
		assertEquals(EstadoContenedor.ROJO, contenedorService.getContenedorById(1).getUltimoRegistro().get().getNivelLlenado());
	}

	@Test
	void updateRejectsUnknownContainerAndInvalidData() {
		assertThrows(RuntimeException.class, () -> contenedorService.actualizarContenedor(99, hoy, 10, EstadoContenedor.VERDE));
		assertThrows(IllegalArgumentException.class, () -> contenedorService.actualizarContenedor(1, hoy, -1, EstadoContenedor.VERDE));
		assertThrows(IllegalArgumentException.class, () -> contenedorService.actualizarContenedor(1, hoy.plusDays(1), 10, EstadoContenedor.VERDE));
	}

	@Test
	void getRegistrosByFechasReturnsTheUpdatesOfThePeriod() {
		contenedorService.actualizarContenedor(1, hoy.minusDays(2), 100, EstadoContenedor.VERDE);
		contenedorService.actualizarContenedor(1, hoy.minusDays(1), 200, EstadoContenedor.VERDE);
		contenedorService.actualizarContenedor(1, hoy, 300, EstadoContenedor.VERDE);

		List<RegistroContenedor> registros = contenedorService.getRegistrosByFechas(1, hoy.minusDays(1), hoy);

		assertEquals(2, registros.size());
		assertEquals(200, registros.get(0).getNumEnvases());
		assertThrows(IllegalArgumentException.class, () -> contenedorService.getRegistrosByFechas(1, hoy, hoy.minusDays(1)));
		assertThrows(RuntimeException.class, () -> contenedorService.getRegistrosByFechas(99, hoy, hoy));
	}

	@Test
	void getRegistrosByZonaOnlyReturnsContainersOfThatZone() {
		contenedorService.actualizarContenedor(1, hoy, 100, EstadoContenedor.VERDE);
		contenedorService.actualizarContenedor(2, hoy, 200, EstadoContenedor.VERDE);

		List<RegistroContenedor> registros = contenedorService.getRegistrosByZona("48001", hoy);

		assertEquals(1, registros.size());
		assertEquals(1, registros.get(0).getContenedor().getId());
		assertTrue(contenedorService.getRegistrosByZona("48001", hoy.minusDays(5)).isEmpty());
	}
}
