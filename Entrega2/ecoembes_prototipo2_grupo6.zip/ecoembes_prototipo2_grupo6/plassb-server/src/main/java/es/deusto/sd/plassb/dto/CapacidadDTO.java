package es.deusto.sd.plassb.dto;

import java.time.LocalDate;

public class CapacidadDTO {
	private String planta;
	private LocalDate fecha;
	private double capacidadDisponible;

	public CapacidadDTO() { }

	public CapacidadDTO(String planta, LocalDate fecha, double capacidadDisponible) {
		this.planta = planta;
		this.fecha = fecha;
		this.capacidadDisponible = capacidadDisponible;
	}

	public String getPlanta() {
		return planta;
	}

	public void setPlanta(String planta) {
		this.planta = planta;
	}

	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	public double getCapacidadDisponible() {
		return capacidadDisponible;
	}

	public void setCapacidadDisponible(double capacidadDisponible) {
		this.capacidadDisponible = capacidadDisponible;
	}
}
