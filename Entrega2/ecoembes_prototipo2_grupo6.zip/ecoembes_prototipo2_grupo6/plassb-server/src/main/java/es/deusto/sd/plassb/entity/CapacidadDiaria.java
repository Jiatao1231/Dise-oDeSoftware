package es.deusto.sd.plassb.entity;

import java.time.LocalDate;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

// Capacidad de reciclaje (en toneladas) que la planta declara para un día concreto
@Entity
public class CapacidadDiaria {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(nullable = false, unique = true)
	private LocalDate fecha;

	private double toneladas;

	public CapacidadDiaria() { }

	public CapacidadDiaria(LocalDate fecha, double toneladas) {
		this.fecha = fecha;
		this.toneladas = toneladas;
	}

	public Long getId() {
		return id;
	}

	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	public double getToneladas() {
		return toneladas;
	}

	public void setToneladas(double toneladas) {
		this.toneladas = toneladas;
	}

	// hashCode and equals based on the business key (fecha), which is unique and non-null
	@Override
	public int hashCode() {
		return Objects.hash(fecha);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CapacidadDiaria other = (CapacidadDiaria) obj;
		return Objects.equals(fecha, other.fecha);
	}
}
