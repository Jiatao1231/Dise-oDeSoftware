package es.deusto.sd.ecoembes.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import es.deusto.sd.ecoembes.entity.PersonalEcoembes;

public interface PersonalRepository extends JpaRepository<PersonalEcoembes, Long> {
	Optional<PersonalEcoembes> findByEmail(String email);
}
