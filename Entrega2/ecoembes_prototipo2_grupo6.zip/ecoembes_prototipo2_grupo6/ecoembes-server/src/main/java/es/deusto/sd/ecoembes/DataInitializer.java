package es.deusto.sd.ecoembes;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import es.deusto.sd.ecoembes.dao.ContenedorRepository;
import es.deusto.sd.ecoembes.dao.PersonalRepository;
import es.deusto.sd.ecoembes.dao.PlantaRepository;
import es.deusto.sd.ecoembes.entity.Contenedor;
import es.deusto.sd.ecoembes.entity.EstadoContenedor;
import es.deusto.sd.ecoembes.entity.PersonalEcoembes;
import es.deusto.sd.ecoembes.entity.PlantaReciclaje;
import es.deusto.sd.ecoembes.entity.TipoServicioPlanta;

@Configuration
public class DataInitializer {

	private static final Logger logger = LoggerFactory.getLogger(DataInitializer.class);

	private final TransactionTemplate transactionTemplate;

	public DataInitializer(PlatformTransactionManager transactionManager) {
		this.transactionTemplate = new TransactionTemplate(transactionManager);
	}

	@Bean
	CommandLineRunner initData(PersonalRepository personalRepository, PlantaRepository plantaRepository,
			ContenedorRepository contenedorRepository) {
		// El runner se ejecuta tras crear los beans; sus inserciones necesitan su propia transacción.
		return args -> transactionTemplate.executeWithoutResult(status -> {
			// La base de datos ya está inicializada
			if (personalRepository.count() > 0) {
				return;
			}

			// Crea personal de Ecoembes
			personalRepository.saveAll(List.of(
					new PersonalEcoembes("Ana Garcia", "ana@ecoembes.com", "Ana1234!"),
					new PersonalEcoembes("Mikel Etxeberria", "mikel@ecoembes.com", "Mikel1234!"),
					new PersonalEcoembes("Laura Perez", "laura@ecoembes.com", "Laura1234!"),
					new PersonalEcoembes("Jiati", "Jiati@ecoembes.com", "Jiati1234!")));

			logger.info("Staff saved!");

			// Crea plantas de reciclaje (acorde al enunciado del proyecto).
			// PlasSB es un servicio REST y ContSocket un servicio basado en sockets.
			plantaRepository.saveAll(List.of(
					new PlantaReciclaje(1, "PlasSB Ltd.", 0.60, TipoServicioPlanta.PLASSB),
					new PlantaReciclaje(2, "ContSocket Ltd.", 0.40, TipoServicioPlanta.CONTSOCKET)));

			logger.info("Recycling plants saved!");

			// Crea contenedores con sus actualizaciones de los últimos 3 días
			String[] ubicaciones = {
				"Gran Via 25, Bilbao", "Calle Autonomia 10, Bilbao", "Alameda Recalde 30, Bilbao",
				"Calle Ercilla 15, Bilbao", "Calle Ledesma 8, Bilbao", "Avenida Lehendakari Aguirre 20, Bilbao",
				"Calle Iparraguirre 40, Bilbao", "Calle Rodriguez Arias 12, Bilbao"
			};
			String[] codigosPostales = { "48001", "48001", "48009", "48009", "48011", "48010", "48011", "48010" };
			int[] numEnvases = { 1100, 1100, 1750, 1300, 1900, 1200, 1500, 200 };

			// Cada contenedor tiene una capacidad inicial de 2000 envases.
			// Se crean actualizaciones para los últimos 3 días, con un número de envases decreciente.
			LocalDate hoy = LocalDate.now();
			int capacidadInicial = 2000;

			for (int i = 0; i < ubicaciones.length; i++) {
				Contenedor contenedor = new Contenedor(i + 1, ubicaciones[i], codigosPostales[i], capacidadInicial);

				for (int dias = 2; dias >= 0; dias--) {
					int envases = Math.max(0, numEnvases[i] - dias * 200);
					contenedor.addRegistro(hoy.minusDays(dias), envases, calcularEstado(envases, capacidadInicial));
				}

				contenedorRepository.save(contenedor);
			}

			logger.info("Containers saved!");
		});
	}

	// Nivel de llenado: VERDE por debajo del 50%, NARANJA por debajo del 80%, ROJO en otro caso
	private EstadoContenedor calcularEstado(int numEnvases, int capacidad) {
		double ocupacion = (double) numEnvases / capacidad;

		if (ocupacion < 0.5) {
			return EstadoContenedor.VERDE;
		} else if (ocupacion < 0.8) {
			return EstadoContenedor.NARANJA;
		} else {
			return EstadoContenedor.ROJO;
		}
	}
}
