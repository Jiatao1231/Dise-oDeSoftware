package es.deusto.sd.ecoembes.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import es.deusto.sd.ecoembes.dao.AlertaRepository;
import es.deusto.sd.ecoembes.entity.AlertaSaturacion;
import es.deusto.sd.ecoembes.entity.Contenedor;
import es.deusto.sd.ecoembes.entity.EstadoContenedor;
import es.deusto.sd.ecoembes.entity.PersonalEcoembes;
import es.deusto.sd.ecoembes.entity.RegistroContenedor;

// Alerta de saturación (opcional): si más del 80 % de todos los contenedores tiene un nivel de llenado
// alto (NARANJA o superior), se envía un correo a todo el personal de Ecoembes.
// Es automática: una tarea programada la comprueba periódicamente, sin ningún endpoint ni controlador.
@Service
public class AlertaSaturacionService {

	private static final Logger logger = LoggerFactory.getLogger(AlertaSaturacionService.class);

	// Porcentaje de contenedores (sobre el total) a partir del cual se considera que hay saturación
	public static final double UMBRAL_SATURACION = 0.80;

	private final ContenedorService contenedorService;
	private final AuthService authService;
	private final EmailService emailService;
	private final AlertaRepository alertaRepository;

	// Evita reenviar la alerta en cada comprobación mientras la saturación continúa.
	// Se desactiva cuando el porcentaje vuelve a estar por debajo del umbral.
	private final AtomicBoolean alertaEnviada = new AtomicBoolean(false);

	public AlertaSaturacionService(ContenedorService contenedorService, AuthService authService,
			EmailService emailService, AlertaRepository alertaRepository) {
		this.contenedorService = contenedorService;
		this.authService = authService;
		this.emailService = emailService;
		this.alertaRepository = alertaRepository;
	}

	// Se ejecuta automáticamente cada cierto tiempo (configurable en application.properties)
	@Scheduled(fixedDelayString = "${ecoembes.alertas.saturacion.intervalo-ms:60000}",
			initialDelayString = "${ecoembes.alertas.saturacion.retardo-inicial-ms:30000}")
	public void comprobarSaturacion() {
		List<Contenedor> contenedores = contenedorService.getContenedores();

		if (contenedores.isEmpty()) {
			return;
		}

		long contenedoresAltos = contenedores.stream().filter(this::tieneNivelAlto).count();
		double porcentaje = (double) contenedoresAltos / contenedores.size();

		if (porcentaje <= UMBRAL_SATURACION) {
			alertaEnviada.set(false); // la situación se ha normalizado: la próxima saturación volverá a avisar
			return;
		}

		// Solo se avisa una vez por episodio de saturación
		if (!alertaEnviada.compareAndSet(false, true)) {
			return;
		}

		try {
			enviarAlerta(contenedoresAltos, contenedores.size(), porcentaje);
		} catch (RuntimeException e) {
			alertaEnviada.set(false); // si falla el envío, se reintenta en la siguiente comprobación
			logger.error("No se pudo enviar la alerta de saturación: {}", e.getMessage());
		}
	}

	// Devuelve las alertas enviadas, de la más reciente a la más antigua
	public List<AlertaSaturacion> getAlertas() {
		return alertaRepository.findAllByOrderByFechaHoraDesc();
	}

	// Un contenedor tiene nivel alto si su última actualización es NARANJA o ROJO (ROJO es aún más lleno)
	private boolean tieneNivelAlto(Contenedor contenedor) {
		return contenedor.getUltimoRegistro()
				.map(RegistroContenedor::getNivelLlenado)
				.map(n -> n == EstadoContenedor.NARANJA || n == EstadoContenedor.ROJO)
				.orElse(false);
	}

	private void enviarAlerta(long contenedoresAltos, int totalContenedores, double porcentaje) {
		List<String> destinatarios = authService.getTodoElPersonal().stream()
				.map(PersonalEcoembes::getEmail)
				.toList();

		if (destinatarios.isEmpty()) {
			throw new IllegalStateException("No staff to notify");
		}

		String asunto = "[Ecoembes] Alerta de saturación de contenedores";
		String resumen = String.format(
				"%d de %d contenedores (%.0f %%) tienen un nivel de llenado alto (naranja o rojo), "
				+ "por encima del umbral del %.0f %%.",
				contenedoresAltos, totalContenedores, porcentaje * 100, UMBRAL_SATURACION * 100);
		String texto = "Alerta de saturación\n\n" + resumen
				+ "\n\nSe recomienda planificar cuanto antes la recogida para evitar desbordamientos.";

		emailService.enviar(destinatarios, asunto, texto);

		// Solo se guarda en el historial si el envío ha funcionado
		alertaRepository.save(new AlertaSaturacion(LocalDateTime.now(), (int) contenedoresAltos, totalContenedores,
				porcentaje * 100, destinatarios, resumen));
		logger.warn("Alerta de saturación enviada a {} personas ({}/{} contenedores con nivel alto)",
				destinatarios.size(), contenedoresAltos, totalContenedores);
	}
}
