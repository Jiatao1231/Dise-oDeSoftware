package es.deusto.sd.contsocket;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// Almacén EN MEMORIA de ContSocket Ltd. (los datos se pierden al parar el servidor).
// Guarda las toneladas ya asignadas por fecha y las asignaciones recibidas desde Ecoembes.
public class CapacidadStore {

	// La capacidad solo está disponible con 10 días de antelación
	public static final int DIAS_ANTELACION = 10;
	// Fechas pasadas con capacidad declarada
	public static final int DIAS_ATRAS = 3;
	// Peso medio de un envase en toneladas (50 gramos)
	public static final double PESO_MEDIO_ENVASE_TONELADAS = 0.00005;

	public record Asignacion(LocalDate fecha, int numContenedores, int totalEnvases, double toneladas) { }

	private final double capacidadDiaria;
	private final Map<LocalDate, Double> asignado = new HashMap<>();
	private final List<Asignacion> asignaciones = new ArrayList<>();

	public CapacidadStore(double capacidadDiaria) {
		this.capacidadDiaria = capacidadDiaria;
	}

	// Capacidad disponible (toneladas) en una fecha. synchronized: el servidor atiende varios clientes a la vez.
	public synchronized double getCapacidadDisponible(LocalDate fecha) {
		validarFecha(fecha);

		return disponible(fecha);
	}

	// Registra una asignación y devuelve la capacidad que queda ese día.
	// Lanza IllegalStateException("Insufficient capacity") si supera la capacidad disponible.
	public synchronized double asignar(LocalDate fecha, int numContenedores, int totalEnvases) {
		if (numContenedores <= 0 || totalEnvases <= 0) {
			throw new IllegalArgumentException("Invalid assignment data");
		}

		validarFecha(fecha);

		double toneladas = redondear(totalEnvases * PESO_MEDIO_ENVASE_TONELADAS);

		if (toneladas > disponible(fecha)) {
			throw new IllegalStateException("Insufficient capacity");
		}

		asignado.merge(fecha, toneladas, Double::sum);
		asignaciones.add(new Asignacion(fecha, numContenedores, totalEnvases, toneladas));

		return disponible(fecha);
	}

	public synchronized List<Asignacion> getAsignaciones() {
		return new ArrayList<>(asignaciones);
	}

	private double disponible(LocalDate fecha) {
		return redondear(Math.max(0.0, capacidadDiaria - asignado.getOrDefault(fecha, 0.0)));
	}

	// Fecha inválida (null o más de 10 días en el futuro) -> IllegalArgumentException;
	// fecha demasiado antigua -> NoSuchElementException (no hay capacidad declarada)
	private void validarFecha(LocalDate fecha) {
		if (fecha == null || fecha.isAfter(LocalDate.now().plusDays(DIAS_ANTELACION))) {
			throw new IllegalArgumentException("Invalid date");
		}

		if (fecha.isBefore(LocalDate.now().minusDays(DIAS_ATRAS))) {
			throw new java.util.NoSuchElementException("Capacity not found");
		}
	}

	private static double redondear(double toneladas) {
		return Math.round(toneladas * 1_000_000d) / 1_000_000d;
	}
}
