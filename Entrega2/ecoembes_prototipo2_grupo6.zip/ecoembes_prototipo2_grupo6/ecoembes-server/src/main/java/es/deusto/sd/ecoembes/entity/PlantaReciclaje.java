package es.deusto.sd.ecoembes.entity;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

// Planta de reciclaje. Su capacidad real NO se guarda aquí: la conoce el servicio externo de la planta
// (PlasSB o ContSocket), al que se accede a través de un Service Gateway.
@Entity
public class PlantaReciclaje {

	// El identificador lo proporciona el sistema (1 = PlasSB, 2 = ContSocket, ...)
	@Id
	private long id;

	@Column(nullable = false)
	private String nombre;

	// Capacidad diaria nominal de la planta (toneladas), solo informativa
	private double capacidadDiaria;

	// Tecnología de su servicio externo: la Factoría decide con ella qué Service Gateway crear
	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	private TipoServicioPlanta tipoServicio;

	// Asignaciones recibidas por la planta (se carga bajo demanda)
	@OneToMany(mappedBy = "planta", fetch = FetchType.LAZY)
	private List<Asignacion> asignaciones = new ArrayList<>();

	// Última capacidad consultada al servicio externo, por fecha (composición con RegistroPlantaReciclaje)
	@OneToMany(mappedBy = "planta", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	private List<RegistroPlantaReciclaje> registros = new ArrayList<>();

	public PlantaReciclaje() { }

	public PlantaReciclaje(long id, String nombre, double capacidadDiaria, TipoServicioPlanta tipoServicio) {
		this.id = id;
		this.nombre = nombre;
		this.capacidadDiaria = capacidadDiaria;
		this.tipoServicio = tipoServicio;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getCapacidadDiaria() {
		return capacidadDiaria;
	}

	public void setCapacidadDiaria(double capacidadDiaria) {
		this.capacidadDiaria = capacidadDiaria;
	}

	public TipoServicioPlanta getTipoServicio() {
		return tipoServicio;
	}

	public void setTipoServicio(TipoServicioPlanta tipoServicio) {
		this.tipoServicio = tipoServicio;
	}

	public List<Asignacion> getAsignaciones() {
		return asignaciones;
	}

	public void setAsignaciones(List<Asignacion> asignaciones) {
		this.asignaciones = asignaciones;
	}

	public List<RegistroPlantaReciclaje> getRegistros() {
		return registros;
	}

	public void setRegistros(List<RegistroPlantaReciclaje> registros) {
		this.registros = registros;
	}

	// hashCode and equals
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PlantaReciclaje other = (PlantaReciclaje) obj;
		return id == other.id;
	}
}
